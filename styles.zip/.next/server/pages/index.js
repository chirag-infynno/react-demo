module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./components/AudioPlayer.js":
/*!***********************************!*\
  !*** ./components/AudioPlayer.js ***!
  \***********************************/
/*! exports provided: AudioPlayer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AudioPlayer", function() { return AudioPlayer; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/AudioPlayer.module.css */ "./styles/AudioPlayer.module.css");
/* harmony import */ var _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons/bs */ "react-icons/bs");
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-icons/fa */ "react-icons/fa");
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-icons/md */ "react-icons/md");
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_5__);


var _jsxFileName = "C:\\Users\\Dell-Pc\\Desktop\\dynamic\\components\\AudioPlayer.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const highLights = [{
  startPosition: 30,
  endPosition: 45
}, {
  startPosition: 40,
  endPosition: 70
}, {
  startPosition: 20,
  endPosition: 40
}];

const AudioPlayer = () => {
  const {
    0: startTime,
    1: setStartTime
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({
    hour: null,
    min: null,
    sec: null
  });
  const {
    0: endTime,
    1: setEndTime
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({
    hour: null,
    min: null,
    sec: null
  });
  const {
    0: blockList,
    1: setBlocakList
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([// {
    //   action: "Exercises ",
    //   endPosition: 13,
    //   id: 1,
    //   startPosition: 9,
    //   timeStampColor: "#FF0000",
    // },
    // {
    //   action: "Questions ",
    //   endPosition: 36,
    //   id: 2,
    //   startPosition: 19,
    //   timeStampColor: "#309c00",
    // },
    // {
    //   "startPosition": 43,
    //   "endPosition": 59,
    //   "timeStampColor": "#fff40f",
    //   "id": 3,
    //   "action": "Need Review ",
    // },
    // {
    //   "startPosition": 44,
    //   "endPosition": 50,
    //   "timeStampColor": "#FF0000",
    //   "id": 1,
    //   "action": "Exercises ",
    // },
  ]);
  const {
    0: isPlaying,
    1: setIsPlaying
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const {
    0: duration,
    1: setDuration
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(0);
  const {
    0: currentTime,
    1: setCurrentTime
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(0);
  const {
    0: highLightBlocks,
    1: setHighLightBlocks
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]);
  const {
    0: index,
    1: setindex
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(0);
  const {
    0: isReplay,
    1: setIsReplay
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false); // references

  const {
    0: audio,
    1: setAudio
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const audioPlayer = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(); // reference our audio component

  const progressBar = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(); // reference our progress bar

  const animationRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(); // reference the animation

  const {
    0: message,
    1: setMessage
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const {
    0: maxValue,
    1: setMaxValue
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();

  const uploadAudio = e => {
    var _e$target$files$, _e$target$files$2;

    if (((_e$target$files$ = e.target.files[0]) === null || _e$target$files$ === void 0 ? void 0 : _e$target$files$.type) === "video/mp4" || ((_e$target$files$2 = e.target.files[0]) === null || _e$target$files$2 === void 0 ? void 0 : _e$target$files$2.type) === "audio/mpeg") {
      var _URL;

      // console.log(":kn");
      setAudio((_URL = URL) === null || _URL === void 0 ? void 0 : _URL.createObjectURL(e.target.files[0]));
      setMessage("");
    } else {
      setMessage("Please Upload Audio/Video file ");
      setAudio();
    } // const seconds = Math.floor(audioPlayer.current.duration);
    // console.log("sec", seconds);
    // setDuration(seconds);
    // progressBar.current.max = seconds;

  }; // const checkVideoOver = (sec) => {
  //   console.log("sec", sec, "duration", duration);
  //   // if (Number(sec) === duration) {
  //   //   setIsPlaying(false);
  //   // }
  // };


  const calculateTime = secs => {
    // checkVideoOver(currentTime);
    // if(sec)
    const minutes = Math.floor(secs / 60);
    const returnedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
    const seconds = Math.floor(secs % 60);
    const returnedSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
    return `${returnedMinutes}:${returnedSeconds}`;
  };

  const calculateTimeEnd = () => {
    // const secs = Math.floor(audioPlayer.current.duration);
    // console.log("get all sec", audioPlayer);
    const minutes = Math.floor(secs / 60);
    const returnedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
    const seconds = Math.floor(secs % 60);
    const returnedSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
    return `${returnedMinutes}:${returnedSeconds}`;
  };

  const {
    0: show,
    1: setShow
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);

  const togglePlayPause = () => {
    if (Number(currentTime) == duration) {
      // if (!prevValue) {
      console.log("aduido player", audioPlayer);
      audioPlayer.current.currentTime = 0;
      audioPlayer.current.play(); // audioPlayer.current.play();
      // animationRef.current = requestAnimationFrame(whilePlaying);
      // }
    } else {
      const prevValue = isPlaying;
      setIsPlaying(!prevValue);

      if (!prevValue) {
        audioPlayer.current.play();
        animationRef.current = requestAnimationFrame(whilePlaying);
      } else {
        audioPlayer.current.pause();
        cancelAnimationFrame(animationRef.current);
      }
    }
  };

  const whilePlaying = () => {
    progressBar.current.value = audioPlayer.current.currentTime;
    changePlayerCurrentTime();
    animationRef.current = requestAnimationFrame(whilePlaying);
  };

  const backThirty = () => {
    progressBar.current.value = Number(progressBar.current.value - 30);
    changeRange();
  };

  const changeStartdate = e => {
    setStartTime(_objectSpread(_objectSpread({}, startTime), {}, {
      [e.target.name]: e.target.value
    }));
  };

  const changeEndTime = e => {
    setEndTime(_objectSpread(_objectSpread({}, endTime), {}, {
      [e.target.name]: e.target.value
    }));
  };

  const countNumber = number => {
    let hour = (number === null || number === void 0 ? void 0 : number.hour) * 3600 || 0;
    let min = (number === null || number === void 0 ? void 0 : number.min) * 60 || 0;
    let sec = Number(number === null || number === void 0 ? void 0 : number.sec) + Number(min) + Number(hour);
    return sec;
  };

  const getBlockPositions = highLightItemData => {
    const find = highLightBlocks.filter(data => {
      if (data.id !== highLightItemData.id) {
        return _objectSpread({}, data);
      }
    });

    if (find.length === highLightBlocks.length) {
      console.log("find ");
      const getSelectdData = blockList.filter(data => {
        return data.id === highLightItemData.id;
      });
      console.log("get all data", getSelectdData);
      let listdata = getSelectdData === null || getSelectdData === void 0 ? void 0 : getSelectdData.map(highLightItem => {
        let leftSpace = Math.trunc((highLightItem === null || highLightItem === void 0 ? void 0 : highLightItem.startPosition) * 570 / duration);
        let endPosition = Math.trunc((highLightItem === null || highLightItem === void 0 ? void 0 : highLightItem.endPosition) * 570 / duration);
        let blockWidth = endPosition - leftSpace;
        return {
          leftSpace: leftSpace,
          blockWidth: blockWidth,
          timeStampColor: highLightItem.timeStampColor,
          id: highLightItem.id,
          index: highLightItem.index + 1 || index + 1
        };
      });
      setHighLightBlocks([...listdata, ...highLightBlocks]);
      setindex(index + 1);
      console.log("listdata", listdata);
    } else {
      let changeIndex = find.map(data => {
        return _objectSpread(_objectSpread({}, data), {}, {
          index: data.index !== 1 ? data.index - 1 : data.index
        });
      });

      if (index > 1) {
        setindex(index - 1);
      } else {
        setindex(0);
      }

      setHighLightBlocks(changeIndex);
    }
  };

  const addExercises = details => {
    let startime = countNumber(startTime);
    let endtime = countNumber(endTime);

    if (startime < endtime && duration > startime && duration >= endtime) {
      const exist = blockList.filter(data => {
        if (startime >= (data === null || data === void 0 ? void 0 : data.startPosition) && startime <= (data === null || data === void 0 ? void 0 : data.endPosition) && (data === null || data === void 0 ? void 0 : data.action) === (details === null || details === void 0 ? void 0 : details.action) || endtime >= (data === null || data === void 0 ? void 0 : data.startPosition) && endtime <= (data === null || data === void 0 ? void 0 : data.endPosition) && (data === null || data === void 0 ? void 0 : data.action) === (details === null || details === void 0 ? void 0 : details.action) || startime <= (data === null || data === void 0 ? void 0 : data.startPosition) && endtime >= (data === null || data === void 0 ? void 0 : data.endPosition) && (data === null || data === void 0 ? void 0 : data.action) === (details === null || details === void 0 ? void 0 : details.action)) {
          return data;
        }
      });

      if ((exist === null || exist === void 0 ? void 0 : exist.length) > 0) {
        setMessage((details === null || details === void 0 ? void 0 : details.action.replace("s", "")) + "Time is Exsits");
      } else {
        setBlocakList([...blockList, {
          startPosition: startime,
          endPosition: endtime,
          timeStampColor: details.color,
          id: details.id,
          action: details.action
        }]);
        setStartTime({
          hour: 0,
          min: 0,
          sec: 0
        });
        setEndTime({
          hour: 0,
          min: 0,
          sec: 0
        });
        setMessage("");
        alert(details.message + "Time is added");
      }
    } else {
      setMessage("Please Enter Valid Time");
    }
  };

  const calculateEndTime = () => {};

  const submtImage = () => {
    // const seconds = Math.floor(audioPlayer.current.duration);
    // setDuration(seconds);
    // progressBar.current.max = seconds;
    setShow(true); // setAudio(e);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    setTimeout(() => {
      var _audioPlayer$current;

      const seconds = Math.floor(audioPlayer === null || audioPlayer === void 0 ? void 0 : (_audioPlayer$current = audioPlayer.current) === null || _audioPlayer$current === void 0 ? void 0 : _audioPlayer$current.duration);
      setDuration(seconds);
      setMaxValue(seconds);
    }, 300);
  }, [highLightBlocks, audio, duration, show]); // useEffect(() => {
  //   // setTimeout(() => {
  //   //   const seconds = Math.floor(audioPlayer?.current?.duration);
  //   //   setDuration(seconds);
  //   //   setMaxValue(seconds);
  //   // }, 300);
  //   console.log("nakscnkn");
  // }, [audioPlayer?.current?.value]);

  const forwardThirty = () => {
    progressBar.current.value = Number(progressBar.current.value + 30);
    changeRange();
  };

  const changeRange = () => {
    audioPlayer.current.currentTime = progressBar.current.value;
    changePlayerCurrentTime();
  };

  const changePlayerCurrentTime = () => {
    progressBar.current.style.setProperty("--seek-before-width", `${progressBar.current.value / duration * 100}%`);
    setCurrentTime(progressBar.current.value);
  };

  const getNewData = e => {
    console.log(e.target.parentElement.offsetLeft + e.target.parentElement.parentElement.offsetLeft, "toatal", e.screenX);
    console.log("final ", e.target.parentElement.offsetLeft + e.target.parentElement.parentElement.offsetLeft - e.screenX);
    let time;
    time = (e.target.parentElement.offsetLeft + e.target.parentElement.parentElement.offsetLeft - e.screenX) / (570 / duration);
    console.log("time ", time);
    progressBar.current.value = Math.abs(Math.floor(time));
    changeRange();
  }; // const router = useRouter();


  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [!show && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: "Upload Audio/Video"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 354,
        columnNumber: 11
      }, undefined), message && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          // position: "absolute",
          color: "red",
          // top: "50px",
          // left: 50,
          marginTop: 10,
          marginBottom: 5
        },
        children: message
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 356,
        columnNumber: 13
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
        type: "file",
        onChange: uploadAudio
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 369,
        columnNumber: 11
      }, undefined), audio && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
        onClick: submtImage // style={{
        //   opacity: show ? 100 : 24,
        // }}
        ,
        children: "Upload Audio/Video"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 372,
        columnNumber: 13
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 353,
      columnNumber: 9
    }, undefined), show && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          display: "flex",
          justifyContent: "space-between"
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.audioPlayer,
          style: {
            display: "flex",
            flexDirection: "column",
            position: "relative"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("video", {
            ref: audioPlayer,
            src: audio,
            preload: "metadata",
            style: {
              height: 326
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 400,
            columnNumber: 15
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.mainRange,
            style: {
              position: "absolute",
              top: 300,
              width: 570 // zIndex: 10,

            },
            onClick: e => getNewData(e),
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
              type: "range",
              className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.progressBar,
              defaultValue: 0,
              ref: progressBar,
              max: maxValue,
              style: {
                pointerEvents: "none"
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 418,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.seekBar,
              children: highLightBlocks === null || highLightBlocks === void 0 ? void 0 : highLightBlocks.map((data, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.seekBar1,
                style: {
                  width: `${data.blockWidth}px`,
                  height: "60%",
                  left: `${data.leftSpace}px`,
                  backgroundColor: `${data.timeStampColor}`,
                  position: "absolute",
                  opacity: 0.7,
                  zIndex: data.index
                }
              }, index, false, {
                fileName: _jsxFileName,
                lineNumber: 428,
                columnNumber: 21
              }, undefined))
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 426,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 408,
            columnNumber: 15
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 392,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.buttonlist,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
            style: {
              backgroundColor: "#FF0000"
            },
            className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.buttonStyle,
            onClick: () => {
              getBlockPositions({
                id: 1
              });
            },
            children: "Exercises"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 447,
            columnNumber: 15
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
            style: {
              backgroundColor: "#309c00"
            },
            className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.buttonStyle,
            onClick: () => getBlockPositions({
              id: 2
            }),
            children: "Questions"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 458,
            columnNumber: 15
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
            className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.buttonStyle,
            style: {
              backgroundColor: "#fff40f"
            },
            onClick: () => getBlockPositions({
              id: 3
            }),
            children: "Need Review"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 467,
            columnNumber: 15
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 446,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 386,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          display: "flex",
          justifyItems: "center",
          marginLeft: 62,
          border: "1px solid black",
          maxWidth: 157,
          marginTop: 10,
          alignItems: "center",
          gap: 10
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
          onClick: togglePlayPause,
          className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.playPause,
          children: Number(currentTime) !== duration ? isPlaying ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__["FaPause"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 497,
            columnNumber: 19
          }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__["FaPlay"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 499,
            columnNumber: 19
          }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_icons_md__WEBPACK_IMPORTED_MODULE_5__["MdOutlineReplayCircleFilled"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 502,
            columnNumber: 17
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 494,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          children: [calculateTime(currentTime), "/", duration && !isNaN(duration) && calculateTime(duration)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 507,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 479,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "custom",
        style: {
          position: "relative"
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          style: {
            position: "absolute",
            color: "red",
            top: "50px",
            left: 50
          },
          children: message
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 545,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            display: "flex",
            flexDirection: "column",
            gap: 40,
            marginLeft: 50
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              display: "flex",
              gap: 10
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "startpositon",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                children: " Start Time"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 571,
                columnNumber: 19
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "alllabel",
                children: [duration > 3600 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                    type: "number",
                    name: "hour",
                    min: 0,
                    max: 23,
                    placeholder: "HH",
                    value: startTime.hour,
                    onChange: changeStartdate
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 575,
                    columnNumber: 25
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 574,
                  columnNumber: 23
                }, undefined), duration > 60 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                    type: "number",
                    name: "min",
                    min: 0,
                    max: 59,
                    value: startTime.min,
                    placeholder: "MM",
                    onChange: changeStartdate
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 588,
                    columnNumber: 25
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 587,
                  columnNumber: 23
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                    type: "number",
                    name: "sec",
                    min: 0 // max={60}
                    ,
                    value: startTime.sec,
                    placeholder: "SS",
                    max: 59,
                    onChange: changeStartdate
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 601,
                    columnNumber: 23
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 600,
                  columnNumber: 21
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 572,
                columnNumber: 19
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 570,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "startpositon",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                children: " End Time"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 615,
                columnNumber: 19
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "alllabel",
                children: [duration > 3600 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                    type: "number",
                    name: "hour",
                    min: 0,
                    max: 24,
                    placeholder: "HH",
                    value: endTime.hour,
                    onChange: changeEndTime
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 620,
                    columnNumber: 25
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 619,
                  columnNumber: 23
                }, undefined), duration > 60 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                    type: "number",
                    name: "min",
                    min: 0,
                    max: 59,
                    value: endTime.min,
                    placeholder: "MM",
                    onChange: changeEndTime
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 633,
                    columnNumber: 25
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 632,
                  columnNumber: 23
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
                    type: "number",
                    name: "sec",
                    min: 0,
                    max: 59,
                    value: endTime.sec,
                    placeholder: "SS",
                    onChange: changeEndTime
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 645,
                    columnNumber: 23
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 644,
                  columnNumber: 21
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 617,
                columnNumber: 19
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 614,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 564,
            columnNumber: 15
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              display: "flex",
              gap: 10
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
              style: {
                backgroundColor: "#FF0000"
              },
              className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.buttonStyle,
              onClick: () => addExercises({
                id: 1,
                color: "#FF0000",
                message: "Exercises Time",
                action: "Exercises "
              }),
              children: "Add Exercises Time"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 664,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
              style: {
                backgroundColor: "#309c00"
              },
              className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.buttonStyle,
              onClick: () => addExercises({
                id: 2,
                color: "#309c00",
                message: "Questions Time",
                action: "Questions "
              }),
              children: "Add Questions Time"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 680,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
              style: {
                backgroundColor: "#fff40f"
              },
              className: _styles_AudioPlayer_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.buttonStyle,
              onClick: () => addExercises({
                id: 3,
                color: "#fff40f",
                message: "Review Time",
                action: "Need Review "
              }),
              children: "Add Need Review Time"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 696,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 658,
            columnNumber: 15
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 555,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 539,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          marginTop: 100
        },
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("table", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tr", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("th", {
              children: "Index"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 722,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("th", {
              children: "Startime"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 723,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("th", {
              children: "EndTime"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 724,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("th", {
              children: "Action"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 725,
              columnNumber: 17
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 721,
            columnNumber: 15
          }, undefined), blockList.map((data, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tr", {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              children: index + 1
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 730,
              columnNumber: 19
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              children: calculateTime(data.startPosition)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 731,
              columnNumber: 19
            }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              children: calculateTime(data.endPosition)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 732,
              columnNumber: 19
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
              style: {
                backgroundColor: data.timeStampColor
              },
              onClick: () => {
                console.log(data);
              },
              children: data.action
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 733,
              columnNumber: 19
            }, undefined)]
          }, index, true, {
            fileName: _jsxFileName,
            lineNumber: 729,
            columnNumber: 17
          }, undefined))]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 720,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 715,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 385,
      columnNumber: 9
    }, undefined)]
  }, void 0, true);
};



/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Home; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/Home.module.css */ "./styles/Home.module.css");
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_AudioPlayer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/AudioPlayer */ "./components/AudioPlayer.js");

var _jsxFileName = "C:\\Users\\Dell-Pc\\Desktop\\dynamic\\pages\\index.js";



function Home() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.container,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
        children: "React Audio Player"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("main", {
      className: _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_2___default.a.main,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_AudioPlayer__WEBPACK_IMPORTED_MODULE_3__["AudioPlayer"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./styles/AudioPlayer.module.css":
/*!***************************************!*\
  !*** ./styles/AudioPlayer.module.css ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Exports
module.exports = {
	"audioPlayer": "AudioPlayer_audioPlayer__XCdVB",
	"forwardBackward": "AudioPlayer_forwardBackward__1bQgX",
	"playPause": "AudioPlayer_playPause__3bqFN",
	"play": "AudioPlayer_play__V8Z5Q",
	"currentTime": "AudioPlayer_currentTime__2sNcg",
	"duration": "AudioPlayer_duration__1YsY5",
	"progressBar": "AudioPlayer_progressBar__9VLnB",
	"mainRange": "AudioPlayer_mainRange__25yIO",
	"seekBar": "AudioPlayer_seekBar__1DOf1",
	"seekBar1": "AudioPlayer_seekBar1__1GWhh",
	"seekBar2": "AudioPlayer_seekBar2__1P4kV",
	"seekBar3": "AudioPlayer_seekBar3__1-NUw",
	"buttonlist": "AudioPlayer_buttonlist__1gQ54",
	"buttonStyle": "AudioPlayer_buttonStyle__XuqTC"
};


/***/ }),

/***/ "./styles/Home.module.css":
/*!********************************!*\
  !*** ./styles/Home.module.css ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Exports
module.exports = {
	"container": "Home_container__1EcsU",
	"main": "Home_main__1x8gC"
};


/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-icons/bs":
/*!*********************************!*\
  !*** external "react-icons/bs" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons/bs");

/***/ }),

/***/ "react-icons/fa":
/*!*********************************!*\
  !*** external "react-icons/fa" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons/fa");

/***/ }),

/***/ "react-icons/md":
/*!*********************************!*\
  !*** external "react-icons/md" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-icons/md");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9BdWRpb1BsYXllci5qcyIsIndlYnBhY2s6Ly8vLi9wYWdlcy9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9zdHlsZXMvQXVkaW9QbGF5ZXIubW9kdWxlLmNzcyIsIndlYnBhY2s6Ly8vLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvaGVhZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QtaWNvbnMvYnNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC1pY29ucy9mYVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0LWljb25zL21kXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIiXSwibmFtZXMiOlsiaGlnaExpZ2h0cyIsInN0YXJ0UG9zaXRpb24iLCJlbmRQb3NpdGlvbiIsIkF1ZGlvUGxheWVyIiwic3RhcnRUaW1lIiwic2V0U3RhcnRUaW1lIiwidXNlU3RhdGUiLCJob3VyIiwibWluIiwic2VjIiwiZW5kVGltZSIsInNldEVuZFRpbWUiLCJibG9ja0xpc3QiLCJzZXRCbG9jYWtMaXN0IiwiaXNQbGF5aW5nIiwic2V0SXNQbGF5aW5nIiwiZHVyYXRpb24iLCJzZXREdXJhdGlvbiIsImN1cnJlbnRUaW1lIiwic2V0Q3VycmVudFRpbWUiLCJoaWdoTGlnaHRCbG9ja3MiLCJzZXRIaWdoTGlnaHRCbG9ja3MiLCJpbmRleCIsInNldGluZGV4IiwiaXNSZXBsYXkiLCJzZXRJc1JlcGxheSIsImF1ZGlvIiwic2V0QXVkaW8iLCJhdWRpb1BsYXllciIsInVzZVJlZiIsInByb2dyZXNzQmFyIiwiYW5pbWF0aW9uUmVmIiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJtYXhWYWx1ZSIsInNldE1heFZhbHVlIiwidXBsb2FkQXVkaW8iLCJlIiwidGFyZ2V0IiwiZmlsZXMiLCJ0eXBlIiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwiY2FsY3VsYXRlVGltZSIsInNlY3MiLCJtaW51dGVzIiwiTWF0aCIsImZsb29yIiwicmV0dXJuZWRNaW51dGVzIiwic2Vjb25kcyIsInJldHVybmVkU2Vjb25kcyIsImNhbGN1bGF0ZVRpbWVFbmQiLCJzaG93Iiwic2V0U2hvdyIsInRvZ2dsZVBsYXlQYXVzZSIsIk51bWJlciIsImNvbnNvbGUiLCJsb2ciLCJjdXJyZW50IiwicGxheSIsInByZXZWYWx1ZSIsInJlcXVlc3RBbmltYXRpb25GcmFtZSIsIndoaWxlUGxheWluZyIsInBhdXNlIiwiY2FuY2VsQW5pbWF0aW9uRnJhbWUiLCJ2YWx1ZSIsImNoYW5nZVBsYXllckN1cnJlbnRUaW1lIiwiYmFja1RoaXJ0eSIsImNoYW5nZVJhbmdlIiwiY2hhbmdlU3RhcnRkYXRlIiwibmFtZSIsImNoYW5nZUVuZFRpbWUiLCJjb3VudE51bWJlciIsIm51bWJlciIsImdldEJsb2NrUG9zaXRpb25zIiwiaGlnaExpZ2h0SXRlbURhdGEiLCJmaW5kIiwiZmlsdGVyIiwiZGF0YSIsImlkIiwibGVuZ3RoIiwiZ2V0U2VsZWN0ZERhdGEiLCJsaXN0ZGF0YSIsIm1hcCIsImhpZ2hMaWdodEl0ZW0iLCJsZWZ0U3BhY2UiLCJ0cnVuYyIsImJsb2NrV2lkdGgiLCJ0aW1lU3RhbXBDb2xvciIsImNoYW5nZUluZGV4IiwiYWRkRXhlcmNpc2VzIiwiZGV0YWlscyIsInN0YXJ0aW1lIiwiZW5kdGltZSIsImV4aXN0IiwiYWN0aW9uIiwicmVwbGFjZSIsImNvbG9yIiwiYWxlcnQiLCJjYWxjdWxhdGVFbmRUaW1lIiwic3VibXRJbWFnZSIsInVzZUVmZmVjdCIsInNldFRpbWVvdXQiLCJmb3J3YXJkVGhpcnR5Iiwic3R5bGUiLCJzZXRQcm9wZXJ0eSIsImdldE5ld0RhdGEiLCJwYXJlbnRFbGVtZW50Iiwib2Zmc2V0TGVmdCIsInNjcmVlblgiLCJ0aW1lIiwiYWJzIiwibWFyZ2luVG9wIiwibWFyZ2luQm90dG9tIiwiZGlzcGxheSIsImp1c3RpZnlDb250ZW50Iiwic3R5bGVzIiwiZmxleERpcmVjdGlvbiIsInBvc2l0aW9uIiwiaGVpZ2h0IiwibWFpblJhbmdlIiwidG9wIiwid2lkdGgiLCJwb2ludGVyRXZlbnRzIiwic2Vla0JhciIsInNlZWtCYXIxIiwibGVmdCIsImJhY2tncm91bmRDb2xvciIsIm9wYWNpdHkiLCJ6SW5kZXgiLCJidXR0b25saXN0IiwiYnV0dG9uU3R5bGUiLCJqdXN0aWZ5SXRlbXMiLCJtYXJnaW5MZWZ0IiwiYm9yZGVyIiwibWF4V2lkdGgiLCJhbGlnbkl0ZW1zIiwiZ2FwIiwicGxheVBhdXNlIiwiaXNOYU4iLCJIb21lIiwiY29udGFpbmVyIiwibWFpbiJdLCJtYXBwaW5ncyI6Ijs7UUFBQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLElBQUk7UUFDSjtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7O1FBR0E7UUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLE1BQU1BLFVBQVUsR0FBRyxDQUNqQjtBQUFFQyxlQUFhLEVBQUUsRUFBakI7QUFBcUJDLGFBQVcsRUFBRTtBQUFsQyxDQURpQixFQUVqQjtBQUFFRCxlQUFhLEVBQUUsRUFBakI7QUFBcUJDLGFBQVcsRUFBRTtBQUFsQyxDQUZpQixFQUdqQjtBQUFFRCxlQUFhLEVBQUUsRUFBakI7QUFBcUJDLGFBQVcsRUFBRTtBQUFsQyxDQUhpQixDQUFuQjs7QUFNQSxNQUFNQyxXQUFXLEdBQUcsTUFBTTtBQUN4QixRQUFNO0FBQUEsT0FBQ0MsU0FBRDtBQUFBLE9BQVlDO0FBQVosTUFBNEJDLHNEQUFRLENBQUM7QUFDekNDLFFBQUksRUFBRSxJQURtQztBQUV6Q0MsT0FBRyxFQUFFLElBRm9DO0FBR3pDQyxPQUFHLEVBQUU7QUFIb0MsR0FBRCxDQUExQztBQUtBLFFBQU07QUFBQSxPQUFDQyxPQUFEO0FBQUEsT0FBVUM7QUFBVixNQUF3Qkwsc0RBQVEsQ0FBQztBQUNyQ0MsUUFBSSxFQUFFLElBRCtCO0FBRXJDQyxPQUFHLEVBQUUsSUFGZ0M7QUFHckNDLE9BQUcsRUFBRTtBQUhnQyxHQUFELENBQXRDO0FBS0EsUUFBTTtBQUFBLE9BQUNHLFNBQUQ7QUFBQSxPQUFZQztBQUFaLE1BQTZCUCxzREFBUSxDQUFDLENBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBNUIwQyxHQUFELENBQTNDO0FBOEJBLFFBQU07QUFBQSxPQUFDUSxTQUFEO0FBQUEsT0FBWUM7QUFBWixNQUE0QlQsc0RBQVEsQ0FBQyxLQUFELENBQTFDO0FBQ0EsUUFBTTtBQUFBLE9BQUNVLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCWCxzREFBUSxDQUFDLENBQUQsQ0FBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQ1ksV0FBRDtBQUFBLE9BQWNDO0FBQWQsTUFBZ0NiLHNEQUFRLENBQUMsQ0FBRCxDQUE5QztBQUNBLFFBQU07QUFBQSxPQUFDYyxlQUFEO0FBQUEsT0FBa0JDO0FBQWxCLE1BQXdDZixzREFBUSxDQUFDLEVBQUQsQ0FBdEQ7QUFDQSxRQUFNO0FBQUEsT0FBQ2dCLEtBQUQ7QUFBQSxPQUFRQztBQUFSLE1BQW9CakIsc0RBQVEsQ0FBQyxDQUFELENBQWxDO0FBRUEsUUFBTTtBQUFBLE9BQUNrQixRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQm5CLHNEQUFRLENBQUMsS0FBRCxDQUF4QyxDQS9Dd0IsQ0FpRHhCOztBQUVBLFFBQU07QUFBQSxPQUFDb0IsS0FBRDtBQUFBLE9BQVFDO0FBQVIsTUFBb0JyQixzREFBUSxFQUFsQztBQUNBLFFBQU1zQixXQUFXLEdBQUdDLG9EQUFNLEVBQTFCLENBcER3QixDQW9ETTs7QUFDOUIsUUFBTUMsV0FBVyxHQUFHRCxvREFBTSxFQUExQixDQXJEd0IsQ0FxRE07O0FBQzlCLFFBQU1FLFlBQVksR0FBR0Ysb0RBQU0sRUFBM0IsQ0F0RHdCLENBc0RPOztBQUMvQixRQUFNO0FBQUEsT0FBQ0csT0FBRDtBQUFBLE9BQVVDO0FBQVYsTUFBd0IzQixzREFBUSxDQUFDLEVBQUQsQ0FBdEM7QUFDQSxRQUFNO0FBQUEsT0FBQzRCLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCN0Isc0RBQVEsRUFBeEM7O0FBRUEsUUFBTThCLFdBQVcsR0FBSUMsQ0FBRCxJQUFPO0FBQUE7O0FBQ3pCLFFBQ0UscUJBQUFBLENBQUMsQ0FBQ0MsTUFBRixDQUFTQyxLQUFULENBQWUsQ0FBZix1RUFBbUJDLElBQW5CLE1BQTRCLFdBQTVCLElBQ0Esc0JBQUFILENBQUMsQ0FBQ0MsTUFBRixDQUFTQyxLQUFULENBQWUsQ0FBZix5RUFBbUJDLElBQW5CLE1BQTRCLFlBRjlCLEVBR0U7QUFBQTs7QUFDQTtBQUNBYixjQUFRLFNBQUNjLEdBQUQseUNBQUMsS0FBS0MsZUFBTCxDQUFxQkwsQ0FBQyxDQUFDQyxNQUFGLENBQVNDLEtBQVQsQ0FBZSxDQUFmLENBQXJCLENBQUQsQ0FBUjtBQUNBTixnQkFBVSxDQUFDLEVBQUQsQ0FBVjtBQUNELEtBUEQsTUFPTztBQUNMQSxnQkFBVSxDQUFDLGlDQUFELENBQVY7QUFDQU4sY0FBUTtBQUNULEtBWHdCLENBYXpCO0FBQ0E7QUFDQTtBQUNBOztBQUNELEdBakJELENBMUR3QixDQTRFeEI7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOzs7QUFFQSxRQUFNZ0IsYUFBYSxHQUFJQyxJQUFELElBQVU7QUFDOUI7QUFDQTtBQUNBLFVBQU1DLE9BQU8sR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdILElBQUksR0FBRyxFQUFsQixDQUFoQjtBQUNBLFVBQU1JLGVBQWUsR0FBR0gsT0FBTyxHQUFHLEVBQVYsR0FBZ0IsSUFBR0EsT0FBUSxFQUEzQixHQUFnQyxHQUFFQSxPQUFRLEVBQWxFO0FBQ0EsVUFBTUksT0FBTyxHQUFHSCxJQUFJLENBQUNDLEtBQUwsQ0FBV0gsSUFBSSxHQUFHLEVBQWxCLENBQWhCO0FBQ0EsVUFBTU0sZUFBZSxHQUFHRCxPQUFPLEdBQUcsRUFBVixHQUFnQixJQUFHQSxPQUFRLEVBQTNCLEdBQWdDLEdBQUVBLE9BQVEsRUFBbEU7QUFDQSxXQUFRLEdBQUVELGVBQWdCLElBQUdFLGVBQWdCLEVBQTdDO0FBQ0QsR0FSRDs7QUFVQSxRQUFNQyxnQkFBZ0IsR0FBRyxNQUFNO0FBQzdCO0FBRUE7QUFDQSxVQUFNTixPQUFPLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXSCxJQUFJLEdBQUcsRUFBbEIsQ0FBaEI7QUFDQSxVQUFNSSxlQUFlLEdBQUdILE9BQU8sR0FBRyxFQUFWLEdBQWdCLElBQUdBLE9BQVEsRUFBM0IsR0FBZ0MsR0FBRUEsT0FBUSxFQUFsRTtBQUNBLFVBQU1JLE9BQU8sR0FBR0gsSUFBSSxDQUFDQyxLQUFMLENBQVdILElBQUksR0FBRyxFQUFsQixDQUFoQjtBQUNBLFVBQU1NLGVBQWUsR0FBR0QsT0FBTyxHQUFHLEVBQVYsR0FBZ0IsSUFBR0EsT0FBUSxFQUEzQixHQUFnQyxHQUFFQSxPQUFRLEVBQWxFO0FBQ0EsV0FBUSxHQUFFRCxlQUFnQixJQUFHRSxlQUFnQixFQUE3QztBQUNELEdBVEQ7O0FBVUEsUUFBTTtBQUFBLE9BQUNFLElBQUQ7QUFBQSxPQUFPQztBQUFQLE1BQWtCL0Msc0RBQVEsQ0FBQyxLQUFELENBQWhDOztBQUNBLFFBQU1nRCxlQUFlLEdBQUcsTUFBTTtBQUM1QixRQUFJQyxNQUFNLENBQUNyQyxXQUFELENBQU4sSUFBdUJGLFFBQTNCLEVBQXFDO0FBQ25DO0FBQ0F3QyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxlQUFaLEVBQTZCN0IsV0FBN0I7QUFFQUEsaUJBQVcsQ0FBQzhCLE9BQVosQ0FBb0J4QyxXQUFwQixHQUFrQyxDQUFsQztBQUNBVSxpQkFBVyxDQUFDOEIsT0FBWixDQUFvQkMsSUFBcEIsR0FMbUMsQ0FNbkM7QUFDQTtBQUNBO0FBQ0QsS0FURCxNQVNPO0FBQ0wsWUFBTUMsU0FBUyxHQUFHOUMsU0FBbEI7QUFDQUMsa0JBQVksQ0FBQyxDQUFDNkMsU0FBRixDQUFaOztBQUNBLFVBQUksQ0FBQ0EsU0FBTCxFQUFnQjtBQUNkaEMsbUJBQVcsQ0FBQzhCLE9BQVosQ0FBb0JDLElBQXBCO0FBQ0E1QixvQkFBWSxDQUFDMkIsT0FBYixHQUF1QkcscUJBQXFCLENBQUNDLFlBQUQsQ0FBNUM7QUFDRCxPQUhELE1BR087QUFDTGxDLG1CQUFXLENBQUM4QixPQUFaLENBQW9CSyxLQUFwQjtBQUNBQyw0QkFBb0IsQ0FBQ2pDLFlBQVksQ0FBQzJCLE9BQWQsQ0FBcEI7QUFDRDtBQUNGO0FBQ0YsR0FyQkQ7O0FBdUJBLFFBQU1JLFlBQVksR0FBRyxNQUFNO0FBQ3pCaEMsZUFBVyxDQUFDNEIsT0FBWixDQUFvQk8sS0FBcEIsR0FBNEJyQyxXQUFXLENBQUM4QixPQUFaLENBQW9CeEMsV0FBaEQ7QUFDQWdELDJCQUF1QjtBQUN2Qm5DLGdCQUFZLENBQUMyQixPQUFiLEdBQXVCRyxxQkFBcUIsQ0FBQ0MsWUFBRCxDQUE1QztBQUNELEdBSkQ7O0FBTUEsUUFBTUssVUFBVSxHQUFHLE1BQU07QUFDdkJyQyxlQUFXLENBQUM0QixPQUFaLENBQW9CTyxLQUFwQixHQUE0QlYsTUFBTSxDQUFDekIsV0FBVyxDQUFDNEIsT0FBWixDQUFvQk8sS0FBcEIsR0FBNEIsRUFBN0IsQ0FBbEM7QUFDQUcsZUFBVztBQUNaLEdBSEQ7O0FBS0EsUUFBTUMsZUFBZSxHQUFJaEMsQ0FBRCxJQUFPO0FBQzdCaEMsZ0JBQVksaUNBQU1ELFNBQU47QUFBaUIsT0FBQ2lDLENBQUMsQ0FBQ0MsTUFBRixDQUFTZ0MsSUFBVixHQUFpQmpDLENBQUMsQ0FBQ0MsTUFBRixDQUFTMkI7QUFBM0MsT0FBWjtBQUNELEdBRkQ7O0FBSUEsUUFBTU0sYUFBYSxHQUFJbEMsQ0FBRCxJQUFPO0FBQzNCMUIsY0FBVSxpQ0FBTUQsT0FBTjtBQUFlLE9BQUMyQixDQUFDLENBQUNDLE1BQUYsQ0FBU2dDLElBQVYsR0FBaUJqQyxDQUFDLENBQUNDLE1BQUYsQ0FBUzJCO0FBQXpDLE9BQVY7QUFDRCxHQUZEOztBQUlBLFFBQU1PLFdBQVcsR0FBSUMsTUFBRCxJQUFZO0FBQzlCLFFBQUlsRSxJQUFJLEdBQUcsQ0FBQWtFLE1BQU0sU0FBTixJQUFBQSxNQUFNLFdBQU4sWUFBQUEsTUFBTSxDQUFFbEUsSUFBUixJQUFlLElBQWYsSUFBdUIsQ0FBbEM7QUFDQSxRQUFJQyxHQUFHLEdBQUcsQ0FBQWlFLE1BQU0sU0FBTixJQUFBQSxNQUFNLFdBQU4sWUFBQUEsTUFBTSxDQUFFakUsR0FBUixJQUFjLEVBQWQsSUFBb0IsQ0FBOUI7QUFDQSxRQUFJQyxHQUFHLEdBQUc4QyxNQUFNLENBQUNrQixNQUFELGFBQUNBLE1BQUQsdUJBQUNBLE1BQU0sQ0FBRWhFLEdBQVQsQ0FBTixHQUFzQjhDLE1BQU0sQ0FBQy9DLEdBQUQsQ0FBNUIsR0FBb0MrQyxNQUFNLENBQUNoRCxJQUFELENBQXBEO0FBQ0EsV0FBT0UsR0FBUDtBQUNELEdBTEQ7O0FBT0EsUUFBTWlFLGlCQUFpQixHQUFJQyxpQkFBRCxJQUF1QjtBQUMvQyxVQUFNQyxJQUFJLEdBQUd4RCxlQUFlLENBQUN5RCxNQUFoQixDQUF3QkMsSUFBRCxJQUFVO0FBQzVDLFVBQUlBLElBQUksQ0FBQ0MsRUFBTCxLQUFZSixpQkFBaUIsQ0FBQ0ksRUFBbEMsRUFBc0M7QUFDcEMsaUNBQ0tELElBREw7QUFHRDtBQUNGLEtBTlksQ0FBYjs7QUFPQSxRQUFJRixJQUFJLENBQUNJLE1BQUwsS0FBZ0I1RCxlQUFlLENBQUM0RCxNQUFwQyxFQUE0QztBQUMxQ3hCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFFQSxZQUFNd0IsY0FBYyxHQUFHckUsU0FBUyxDQUFDaUUsTUFBVixDQUFrQkMsSUFBRCxJQUFVO0FBQ2hELGVBQU9BLElBQUksQ0FBQ0MsRUFBTCxLQUFZSixpQkFBaUIsQ0FBQ0ksRUFBckM7QUFDRCxPQUZzQixDQUF2QjtBQUlBdkIsYUFBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUE0QndCLGNBQTVCO0FBRUEsVUFBSUMsUUFBUSxHQUFHRCxjQUFILGFBQUdBLGNBQUgsdUJBQUdBLGNBQWMsQ0FBRUUsR0FBaEIsQ0FBcUJDLGFBQUQsSUFBbUI7QUFDcEQsWUFBSUMsU0FBUyxHQUFHdkMsSUFBSSxDQUFDd0MsS0FBTCxDQUNiLENBQUFGLGFBQWEsU0FBYixJQUFBQSxhQUFhLFdBQWIsWUFBQUEsYUFBYSxDQUFFbkYsYUFBZixJQUErQixHQUFoQyxHQUF1Q2UsUUFEekIsQ0FBaEI7QUFHQSxZQUFJZCxXQUFXLEdBQUc0QyxJQUFJLENBQUN3QyxLQUFMLENBQ2YsQ0FBQUYsYUFBYSxTQUFiLElBQUFBLGFBQWEsV0FBYixZQUFBQSxhQUFhLENBQUVsRixXQUFmLElBQTZCLEdBQTlCLEdBQXFDYyxRQURyQixDQUFsQjtBQUdBLFlBQUl1RSxVQUFVLEdBQUdyRixXQUFXLEdBQUdtRixTQUEvQjtBQUNBLGVBQU87QUFDTEEsbUJBQVMsRUFBRUEsU0FETjtBQUVMRSxvQkFBVSxFQUFFQSxVQUZQO0FBR0xDLHdCQUFjLEVBQUVKLGFBQWEsQ0FBQ0ksY0FIekI7QUFJTFQsWUFBRSxFQUFFSyxhQUFhLENBQUNMLEVBSmI7QUFLTHpELGVBQUssRUFBRThELGFBQWEsQ0FBQzlELEtBQWQsR0FBc0IsQ0FBdEIsSUFBMkJBLEtBQUssR0FBRztBQUxyQyxTQUFQO0FBT0QsT0FmYyxDQUFmO0FBZ0JBRCx3QkFBa0IsQ0FBQyxDQUFDLEdBQUc2RCxRQUFKLEVBQWMsR0FBRzlELGVBQWpCLENBQUQsQ0FBbEI7QUFDQUcsY0FBUSxDQUFDRCxLQUFLLEdBQUcsQ0FBVCxDQUFSO0FBQ0FrQyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCeUIsUUFBeEI7QUFDRCxLQTVCRCxNQTRCTztBQUNMLFVBQUlPLFdBQVcsR0FBR2IsSUFBSSxDQUFDTyxHQUFMLENBQVVMLElBQUQsSUFBVTtBQUNuQywrQ0FDS0EsSUFETDtBQUVFeEQsZUFBSyxFQUFFd0QsSUFBSSxDQUFDeEQsS0FBTCxLQUFlLENBQWYsR0FBbUJ3RCxJQUFJLENBQUN4RCxLQUFMLEdBQWEsQ0FBaEMsR0FBb0N3RCxJQUFJLENBQUN4RDtBQUZsRDtBQUlELE9BTGlCLENBQWxCOztBQU9BLFVBQUlBLEtBQUssR0FBRyxDQUFaLEVBQWU7QUFDYkMsZ0JBQVEsQ0FBQ0QsS0FBSyxHQUFHLENBQVQsQ0FBUjtBQUNELE9BRkQsTUFFTztBQUNMQyxnQkFBUSxDQUFDLENBQUQsQ0FBUjtBQUNEOztBQUNERix3QkFBa0IsQ0FBQ29FLFdBQUQsQ0FBbEI7QUFDRDtBQUNGLEdBbkREOztBQXFEQSxRQUFNQyxZQUFZLEdBQUlDLE9BQUQsSUFBYTtBQUNoQyxRQUFJQyxRQUFRLEdBQUdwQixXQUFXLENBQUNwRSxTQUFELENBQTFCO0FBQ0EsUUFBSXlGLE9BQU8sR0FBR3JCLFdBQVcsQ0FBQzlELE9BQUQsQ0FBekI7O0FBRUEsUUFBSWtGLFFBQVEsR0FBR0MsT0FBWCxJQUFzQjdFLFFBQVEsR0FBRzRFLFFBQWpDLElBQTZDNUUsUUFBUSxJQUFJNkUsT0FBN0QsRUFBc0U7QUFDcEUsWUFBTUMsS0FBSyxHQUFHbEYsU0FBUyxDQUFDaUUsTUFBVixDQUFrQkMsSUFBRCxJQUFVO0FBQ3ZDLFlBQ0djLFFBQVEsS0FBSWQsSUFBSixhQUFJQSxJQUFKLHVCQUFJQSxJQUFJLENBQUU3RSxhQUFWLENBQVIsSUFDQzJGLFFBQVEsS0FBSWQsSUFBSixhQUFJQSxJQUFKLHVCQUFJQSxJQUFJLENBQUU1RSxXQUFWLENBRFQsSUFFQyxDQUFBNEUsSUFBSSxTQUFKLElBQUFBLElBQUksV0FBSixZQUFBQSxJQUFJLENBQUVpQixNQUFOLE9BQWlCSixPQUFqQixhQUFpQkEsT0FBakIsdUJBQWlCQSxPQUFPLENBQUVJLE1BQTFCLENBRkYsSUFHQ0YsT0FBTyxLQUFJZixJQUFKLGFBQUlBLElBQUosdUJBQUlBLElBQUksQ0FBRTdFLGFBQVYsQ0FBUCxJQUNDNEYsT0FBTyxLQUFJZixJQUFKLGFBQUlBLElBQUosdUJBQUlBLElBQUksQ0FBRTVFLFdBQVYsQ0FEUixJQUVDLENBQUE0RSxJQUFJLFNBQUosSUFBQUEsSUFBSSxXQUFKLFlBQUFBLElBQUksQ0FBRWlCLE1BQU4sT0FBaUJKLE9BQWpCLGFBQWlCQSxPQUFqQix1QkFBaUJBLE9BQU8sQ0FBRUksTUFBMUIsQ0FMRixJQU1DSCxRQUFRLEtBQUlkLElBQUosYUFBSUEsSUFBSix1QkFBSUEsSUFBSSxDQUFFN0UsYUFBVixDQUFSLElBQ0M0RixPQUFPLEtBQUlmLElBQUosYUFBSUEsSUFBSix1QkFBSUEsSUFBSSxDQUFFNUUsV0FBVixDQURSLElBRUMsQ0FBQTRFLElBQUksU0FBSixJQUFBQSxJQUFJLFdBQUosWUFBQUEsSUFBSSxDQUFFaUIsTUFBTixPQUFpQkosT0FBakIsYUFBaUJBLE9BQWpCLHVCQUFpQkEsT0FBTyxDQUFFSSxNQUExQixDQVRKLEVBVUU7QUFDQSxpQkFBT2pCLElBQVA7QUFDRDtBQUNGLE9BZGEsQ0FBZDs7QUFnQkEsVUFBSSxDQUFBZ0IsS0FBSyxTQUFMLElBQUFBLEtBQUssV0FBTCxZQUFBQSxLQUFLLENBQUVkLE1BQVAsSUFBZ0IsQ0FBcEIsRUFBdUI7QUFDckIvQyxrQkFBVSxDQUFDLENBQUEwRCxPQUFPLFNBQVAsSUFBQUEsT0FBTyxXQUFQLFlBQUFBLE9BQU8sQ0FBRUksTUFBVCxDQUFnQkMsT0FBaEIsQ0FBd0IsR0FBeEIsRUFBNkIsRUFBN0IsS0FBbUMsZ0JBQXBDLENBQVY7QUFDRCxPQUZELE1BRU87QUFDTG5GLHFCQUFhLENBQUMsQ0FDWixHQUFHRCxTQURTLEVBRVo7QUFDRVgsdUJBQWEsRUFBRTJGLFFBRGpCO0FBRUUxRixxQkFBVyxFQUFFMkYsT0FGZjtBQUdFTCx3QkFBYyxFQUFFRyxPQUFPLENBQUNNLEtBSDFCO0FBSUVsQixZQUFFLEVBQUVZLE9BQU8sQ0FBQ1osRUFKZDtBQUtFZ0IsZ0JBQU0sRUFBRUosT0FBTyxDQUFDSTtBQUxsQixTQUZZLENBQUQsQ0FBYjtBQVdBMUYsb0JBQVksQ0FBQztBQUNYRSxjQUFJLEVBQUUsQ0FESztBQUVYQyxhQUFHLEVBQUUsQ0FGTTtBQUdYQyxhQUFHLEVBQUU7QUFITSxTQUFELENBQVo7QUFNQUUsa0JBQVUsQ0FBQztBQUNUSixjQUFJLEVBQUUsQ0FERztBQUVUQyxhQUFHLEVBQUUsQ0FGSTtBQUdUQyxhQUFHLEVBQUU7QUFISSxTQUFELENBQVY7QUFLQXdCLGtCQUFVLENBQUMsRUFBRCxDQUFWO0FBQ0FpRSxhQUFLLENBQUNQLE9BQU8sQ0FBQzNELE9BQVIsR0FBa0IsZUFBbkIsQ0FBTDtBQUNEO0FBQ0YsS0E3Q0QsTUE2Q087QUFDTEMsZ0JBQVUsQ0FBQyx5QkFBRCxDQUFWO0FBQ0Q7QUFDRixHQXBERDs7QUFzREEsUUFBTWtFLGdCQUFnQixHQUFHLE1BQU0sQ0FBRSxDQUFqQzs7QUFDQSxRQUFNQyxVQUFVLEdBQUcsTUFBTTtBQUN2QjtBQUNBO0FBQ0E7QUFFQS9DLFdBQU8sQ0FBQyxJQUFELENBQVAsQ0FMdUIsQ0FPdkI7QUFDRCxHQVJEOztBQVVBZ0QseURBQVMsQ0FBQyxNQUFNO0FBQ2RDLGNBQVUsQ0FBQyxNQUFNO0FBQUE7O0FBQ2YsWUFBTXJELE9BQU8sR0FBR0gsSUFBSSxDQUFDQyxLQUFMLENBQVduQixXQUFYLGFBQVdBLFdBQVgsK0NBQVdBLFdBQVcsQ0FBRThCLE9BQXhCLHlEQUFXLHFCQUFzQjFDLFFBQWpDLENBQWhCO0FBQ0FDLGlCQUFXLENBQUNnQyxPQUFELENBQVg7QUFDQWQsaUJBQVcsQ0FBQ2MsT0FBRCxDQUFYO0FBQ0QsS0FKUyxFQUlQLEdBSk8sQ0FBVjtBQUtELEdBTlEsRUFNTixDQUFDN0IsZUFBRCxFQUFrQk0sS0FBbEIsRUFBeUJWLFFBQXpCLEVBQW1Db0MsSUFBbkMsQ0FOTSxDQUFULENBaFJ3QixDQXdSeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQSxRQUFNbUQsYUFBYSxHQUFHLE1BQU07QUFDMUJ6RSxlQUFXLENBQUM0QixPQUFaLENBQW9CTyxLQUFwQixHQUE0QlYsTUFBTSxDQUFDekIsV0FBVyxDQUFDNEIsT0FBWixDQUFvQk8sS0FBcEIsR0FBNEIsRUFBN0IsQ0FBbEM7QUFDQUcsZUFBVztBQUNaLEdBSEQ7O0FBS0EsUUFBTUEsV0FBVyxHQUFHLE1BQU07QUFDeEJ4QyxlQUFXLENBQUM4QixPQUFaLENBQW9CeEMsV0FBcEIsR0FBa0NZLFdBQVcsQ0FBQzRCLE9BQVosQ0FBb0JPLEtBQXREO0FBQ0FDLDJCQUF1QjtBQUN4QixHQUhEOztBQUtBLFFBQU1BLHVCQUF1QixHQUFHLE1BQU07QUFDcENwQyxlQUFXLENBQUM0QixPQUFaLENBQW9COEMsS0FBcEIsQ0FBMEJDLFdBQTFCLENBQ0UscUJBREYsRUFFRyxHQUFHM0UsV0FBVyxDQUFDNEIsT0FBWixDQUFvQk8sS0FBcEIsR0FBNEJqRCxRQUE3QixHQUF5QyxHQUFJLEdBRmxEO0FBSUFHLGtCQUFjLENBQUNXLFdBQVcsQ0FBQzRCLE9BQVosQ0FBb0JPLEtBQXJCLENBQWQ7QUFDRCxHQU5EOztBQU9BLFFBQU15QyxVQUFVLEdBQUlyRSxDQUFELElBQU87QUFDeEJtQixXQUFPLENBQUNDLEdBQVIsQ0FDRXBCLENBQUMsQ0FBQ0MsTUFBRixDQUFTcUUsYUFBVCxDQUF1QkMsVUFBdkIsR0FDRXZFLENBQUMsQ0FBQ0MsTUFBRixDQUFTcUUsYUFBVCxDQUF1QkEsYUFBdkIsQ0FBcUNDLFVBRnpDLEVBR0UsUUFIRixFQUlFdkUsQ0FBQyxDQUFDd0UsT0FKSjtBQU9BckQsV0FBTyxDQUFDQyxHQUFSLENBQ0UsUUFERixFQUVFcEIsQ0FBQyxDQUFDQyxNQUFGLENBQVNxRSxhQUFULENBQXVCQyxVQUF2QixHQUNFdkUsQ0FBQyxDQUFDQyxNQUFGLENBQVNxRSxhQUFULENBQXVCQSxhQUF2QixDQUFxQ0MsVUFEdkMsR0FFRXZFLENBQUMsQ0FBQ3dFLE9BSk47QUFNQSxRQUFJQyxJQUFKO0FBQ0FBLFFBQUksR0FDRixDQUFDekUsQ0FBQyxDQUFDQyxNQUFGLENBQVNxRSxhQUFULENBQXVCQyxVQUF2QixHQUNDdkUsQ0FBQyxDQUFDQyxNQUFGLENBQVNxRSxhQUFULENBQXVCQSxhQUF2QixDQUFxQ0MsVUFEdEMsR0FFQ3ZFLENBQUMsQ0FBQ3dFLE9BRkosS0FHQyxNQUFNN0YsUUFIUCxDQURGO0FBS0F3QyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCcUQsSUFBckI7QUFDQWhGLGVBQVcsQ0FBQzRCLE9BQVosQ0FBb0JPLEtBQXBCLEdBQTRCbkIsSUFBSSxDQUFDaUUsR0FBTCxDQUFTakUsSUFBSSxDQUFDQyxLQUFMLENBQVcrRCxJQUFYLENBQVQsQ0FBNUI7QUFFQTFDLGVBQVc7QUFDWixHQXhCRCxDQW5Ud0IsQ0E2VXhCOzs7QUFFQSxzQkFDRTtBQUFBLGVBQ0csQ0FBQ2hCLElBQUQsaUJBQ0M7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixFQUVHcEIsT0FBTyxpQkFDTjtBQUNFLGFBQUssRUFBRTtBQUNMO0FBQ0FpRSxlQUFLLEVBQUUsS0FGRjtBQUdMO0FBQ0E7QUFDQWUsbUJBQVMsRUFBRSxFQUxOO0FBTUxDLHNCQUFZLEVBQUU7QUFOVCxTQURUO0FBQUEsa0JBVUdqRjtBQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSEosZUFnQkU7QUFBTyxZQUFJLEVBQUMsTUFBWjtBQUFtQixnQkFBUSxFQUFFSTtBQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWhCRixFQWtCR1YsS0FBSyxpQkFDSjtBQUNFLGVBQU8sRUFBRTBFLFVBRFgsQ0FFRTtBQUNBO0FBQ0E7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZKLEVBaUNHaEQsSUFBSSxpQkFDSDtBQUFBLDhCQUNFO0FBQ0UsYUFBSyxFQUFFO0FBQ0w4RCxpQkFBTyxFQUFFLE1BREo7QUFFTEMsd0JBQWMsRUFBRTtBQUZYLFNBRFQ7QUFBQSxnQ0FNRTtBQUNFLG1CQUFTLEVBQUVDLHFFQUFNLENBQUN4RixXQURwQjtBQUVFLGVBQUssRUFBRTtBQUNMc0YsbUJBQU8sRUFBRSxNQURKO0FBRUxHLHlCQUFhLEVBQUUsUUFGVjtBQUdMQyxvQkFBUSxFQUFFO0FBSEwsV0FGVDtBQUFBLGtDQVFFO0FBQ0UsZUFBRyxFQUFFMUYsV0FEUDtBQUVFLGVBQUcsRUFBRUYsS0FGUDtBQUdFLG1CQUFPLEVBQUMsVUFIVjtBQUlFLGlCQUFLLEVBQUU7QUFDTDZGLG9CQUFNLEVBQUU7QUFESDtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUkYsZUFnQkU7QUFDRSxxQkFBUyxFQUFFSCxxRUFBTSxDQUFDSSxTQURwQjtBQUVFLGlCQUFLLEVBQUU7QUFDTEYsc0JBQVEsRUFBRSxVQURMO0FBRUxHLGlCQUFHLEVBQUUsR0FGQTtBQUdMQyxtQkFBSyxFQUFFLEdBSEYsQ0FJTDs7QUFKSyxhQUZUO0FBUUUsbUJBQU8sRUFBR3JGLENBQUQsSUFBT3FFLFVBQVUsQ0FBQ3JFLENBQUQsQ0FSNUI7QUFBQSxvQ0FVRTtBQUNFLGtCQUFJLEVBQUMsT0FEUDtBQUVFLHVCQUFTLEVBQUUrRSxxRUFBTSxDQUFDdEYsV0FGcEI7QUFHRSwwQkFBWSxFQUFFLENBSGhCO0FBSUUsaUJBQUcsRUFBRUEsV0FKUDtBQUtFLGlCQUFHLEVBQUVJLFFBTFA7QUFNRSxtQkFBSyxFQUFFO0FBQUV5Riw2QkFBYSxFQUFFO0FBQWpCO0FBTlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFWRixlQWtCRTtBQUFLLHVCQUFTLEVBQUVQLHFFQUFNLENBQUNRLE9BQXZCO0FBQUEsd0JBQ0d4RyxlQURILGFBQ0dBLGVBREgsdUJBQ0dBLGVBQWUsQ0FBRStELEdBQWpCLENBQXFCLENBQUNMLElBQUQsRUFBT3hELEtBQVAsa0JBQ3BCO0FBRUUseUJBQVMsRUFBRThGLHFFQUFNLENBQUNTLFFBRnBCO0FBR0UscUJBQUssRUFBRTtBQUNMSCx1QkFBSyxFQUFHLEdBQUU1QyxJQUFJLENBQUNTLFVBQVcsSUFEckI7QUFFTGdDLHdCQUFNLEVBQUUsS0FGSDtBQUdMTyxzQkFBSSxFQUFHLEdBQUVoRCxJQUFJLENBQUNPLFNBQVUsSUFIbkI7QUFJTDBDLGlDQUFlLEVBQUcsR0FBRWpELElBQUksQ0FBQ1UsY0FBZSxFQUpuQztBQUtMOEIsMEJBQVEsRUFBRSxVQUxMO0FBTUxVLHlCQUFPLEVBQUUsR0FOSjtBQU9MQyx3QkFBTSxFQUFFbkQsSUFBSSxDQUFDeEQ7QUFQUjtBQUhULGlCQUNPQSxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREQ7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFORixlQTRERTtBQUFLLG1CQUFTLEVBQUU4RixxRUFBTSxDQUFDYyxVQUF2QjtBQUFBLGtDQUNFO0FBQ0UsaUJBQUssRUFBRTtBQUNMSCw2QkFBZSxFQUFFO0FBRFosYUFEVDtBQUlFLHFCQUFTLEVBQUVYLHFFQUFNLENBQUNlLFdBSnBCO0FBS0UsbUJBQU8sRUFBRSxNQUFNO0FBQ2J6RCwrQkFBaUIsQ0FBQztBQUFFSyxrQkFBRSxFQUFFO0FBQU4sZUFBRCxDQUFqQjtBQUNELGFBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFZRTtBQUNFLGlCQUFLLEVBQUU7QUFDTGdELDZCQUFlLEVBQUU7QUFEWixhQURUO0FBSUUscUJBQVMsRUFBRVgscUVBQU0sQ0FBQ2UsV0FKcEI7QUFLRSxtQkFBTyxFQUFFLE1BQU16RCxpQkFBaUIsQ0FBQztBQUFFSyxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFaRixlQXFCRTtBQUNFLHFCQUFTLEVBQUVxQyxxRUFBTSxDQUFDZSxXQURwQjtBQUVFLGlCQUFLLEVBQUU7QUFDTEosNkJBQWUsRUFBRTtBQURaLGFBRlQ7QUFLRSxtQkFBTyxFQUFFLE1BQU1yRCxpQkFBaUIsQ0FBQztBQUFFSyxnQkFBRSxFQUFFO0FBQU4sYUFBRCxDQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUE4RkU7QUFDRSxhQUFLLEVBQUU7QUFDTG1DLGlCQUFPLEVBQUUsTUFESjtBQUVMa0Isc0JBQVksRUFBRSxRQUZUO0FBR0xDLG9CQUFVLEVBQUUsRUFIUDtBQUlMQyxnQkFBTSxFQUFFLGlCQUpIO0FBS0xDLGtCQUFRLEVBQUUsR0FMTDtBQU1MdkIsbUJBQVMsRUFBRSxFQU5OO0FBT0x3QixvQkFBVSxFQUFFLFFBUFA7QUFRTEMsYUFBRyxFQUFFO0FBUkEsU0FEVDtBQUFBLGdDQWVFO0FBQVEsaUJBQU8sRUFBRW5GLGVBQWpCO0FBQWtDLG1CQUFTLEVBQUU4RCxxRUFBTSxDQUFDc0IsU0FBcEQ7QUFBQSxvQkFDR25GLE1BQU0sQ0FBQ3JDLFdBQUQsQ0FBTixLQUF3QkYsUUFBeEIsR0FDQ0YsU0FBUyxnQkFDUCxxRUFBQyxzREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURPLGdCQUdQLHFFQUFDLHFEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSkgsZ0JBT0MscUVBQUMsMEVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZkYsZUE0QkU7QUFBQSxxQkFDRzZCLGFBQWEsQ0FBQ3pCLFdBQUQsQ0FEaEIsT0FLR0YsUUFBUSxJQUFJLENBQUMySCxLQUFLLENBQUMzSCxRQUFELENBQWxCLElBQWdDMkIsYUFBYSxDQUFDM0IsUUFBRCxDQUxoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE5RkYsZUEwSkU7QUFDRSxpQkFBUyxFQUFDLFFBRFo7QUFFRSxhQUFLLEVBQUU7QUFDTHNHLGtCQUFRLEVBQUU7QUFETCxTQUZUO0FBQUEsZ0NBTUU7QUFDRSxlQUFLLEVBQUU7QUFDTEEsb0JBQVEsRUFBRSxVQURMO0FBRUxyQixpQkFBSyxFQUFFLEtBRkY7QUFHTHdCLGVBQUcsRUFBRSxNQUhBO0FBSUxLLGdCQUFJLEVBQUU7QUFKRCxXQURUO0FBQUEsb0JBUUc5RjtBQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTkYsZUFnQkU7QUFDRSxtQkFBUyxFQUFDLEVBRFo7QUFFRSxlQUFLLEVBQUU7QUFDTGtGLG1CQUFPLEVBQUUsTUFESjtBQUVMRyx5QkFBYSxFQUFFLFFBRlY7QUFHTG9CLGVBQUcsRUFBRSxFQUhBO0FBSUxKLHNCQUFVLEVBQUU7QUFKUCxXQUZUO0FBQUEsa0NBU0U7QUFDRSxpQkFBSyxFQUFFO0FBQ0xuQixxQkFBTyxFQUFFLE1BREo7QUFFTHVCLGlCQUFHLEVBQUU7QUFGQSxhQURUO0FBQUEsb0NBTUU7QUFBSyx1QkFBUyxFQUFDLGNBQWY7QUFBQSxzQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQUVFO0FBQUsseUJBQVMsRUFBQyxVQUFmO0FBQUEsMkJBQ0d6SCxRQUFRLEdBQUcsSUFBWCxpQkFDQztBQUFBLHlDQUNFO0FBQ0Usd0JBQUksRUFBQyxRQURQO0FBRUUsd0JBQUksRUFBQyxNQUZQO0FBR0UsdUJBQUcsRUFBRSxDQUhQO0FBSUUsdUJBQUcsRUFBRSxFQUpQO0FBS0UsK0JBQVcsRUFBQyxJQUxkO0FBTUUseUJBQUssRUFBRVosU0FBUyxDQUFDRyxJQU5uQjtBQU9FLDRCQUFRLEVBQUU4RDtBQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUZKLEVBY0dyRCxRQUFRLEdBQUcsRUFBWCxpQkFDQztBQUFBLHlDQUNFO0FBQ0Usd0JBQUksRUFBQyxRQURQO0FBRUUsd0JBQUksRUFBQyxLQUZQO0FBR0UsdUJBQUcsRUFBRSxDQUhQO0FBSUUsdUJBQUcsRUFBRSxFQUpQO0FBS0UseUJBQUssRUFBRVosU0FBUyxDQUFDSSxHQUxuQjtBQU1FLCtCQUFXLEVBQUMsSUFOZDtBQU9FLDRCQUFRLEVBQUU2RDtBQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWZKLGVBNEJFO0FBQUEseUNBQ0U7QUFDRSx3QkFBSSxFQUFDLFFBRFA7QUFFRSx3QkFBSSxFQUFDLEtBRlA7QUFHRSx1QkFBRyxFQUFFLENBSFAsQ0FJRTtBQUpGO0FBS0UseUJBQUssRUFBRWpFLFNBQVMsQ0FBQ0ssR0FMbkI7QUFNRSwrQkFBVyxFQUFDLElBTmQ7QUFPRSx1QkFBRyxFQUFFLEVBUFA7QUFRRSw0QkFBUSxFQUFFNEQ7QUFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFORixlQWtERTtBQUFLLHVCQUFTLEVBQUMsY0FBZjtBQUFBLHNDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBR0U7QUFBSyx5QkFBUyxFQUFDLFVBQWY7QUFBQSwyQkFDR3JELFFBQVEsR0FBRyxJQUFYLGlCQUNDO0FBQUEseUNBQ0U7QUFDRSx3QkFBSSxFQUFDLFFBRFA7QUFFRSx3QkFBSSxFQUFDLE1BRlA7QUFHRSx1QkFBRyxFQUFFLENBSFA7QUFJRSx1QkFBRyxFQUFFLEVBSlA7QUFLRSwrQkFBVyxFQUFDLElBTGQ7QUFNRSx5QkFBSyxFQUFFTixPQUFPLENBQUNILElBTmpCO0FBT0UsNEJBQVEsRUFBRWdFO0FBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRkosRUFjR3ZELFFBQVEsR0FBRyxFQUFYLGlCQUNDO0FBQUEseUNBQ0U7QUFDRSx3QkFBSSxFQUFDLFFBRFA7QUFFRSx3QkFBSSxFQUFDLEtBRlA7QUFHRSx1QkFBRyxFQUFFLENBSFA7QUFJRSx1QkFBRyxFQUFFLEVBSlA7QUFLRSx5QkFBSyxFQUFFTixPQUFPLENBQUNGLEdBTGpCO0FBTUUsK0JBQVcsRUFBQyxJQU5kO0FBT0UsNEJBQVEsRUFBRStEO0FBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBZkosZUEyQkU7QUFBQSx5Q0FDRTtBQUNFLHdCQUFJLEVBQUMsUUFEUDtBQUVFLHdCQUFJLEVBQUMsS0FGUDtBQUdFLHVCQUFHLEVBQUUsQ0FIUDtBQUlFLHVCQUFHLEVBQUUsRUFKUDtBQUtFLHlCQUFLLEVBQUU3RCxPQUFPLENBQUNELEdBTGpCO0FBTUUsK0JBQVcsRUFBQyxJQU5kO0FBT0UsNEJBQVEsRUFBRThEO0FBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFURixlQXVHRTtBQUNFLGlCQUFLLEVBQUU7QUFDTDJDLHFCQUFPLEVBQUUsTUFESjtBQUVMdUIsaUJBQUcsRUFBRTtBQUZBLGFBRFQ7QUFBQSxvQ0FNRTtBQUNFLG1CQUFLLEVBQUU7QUFDTFYsK0JBQWUsRUFBRTtBQURaLGVBRFQ7QUFJRSx1QkFBUyxFQUFFWCxxRUFBTSxDQUFDZSxXQUpwQjtBQUtFLHFCQUFPLEVBQUUsTUFDUHpDLFlBQVksQ0FBQztBQUNYWCxrQkFBRSxFQUFFLENBRE87QUFFWGtCLHFCQUFLLEVBQUUsU0FGSTtBQUdYakUsdUJBQU8sRUFBRSxnQkFIRTtBQUlYK0Qsc0JBQU0sRUFBRTtBQUpHLGVBQUQsQ0FOaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTkYsZUFzQkU7QUFDRSxtQkFBSyxFQUFFO0FBQ0xnQywrQkFBZSxFQUFFO0FBRFosZUFEVDtBQUlFLHVCQUFTLEVBQUVYLHFFQUFNLENBQUNlLFdBSnBCO0FBS0UscUJBQU8sRUFBRSxNQUNQekMsWUFBWSxDQUFDO0FBQ1hYLGtCQUFFLEVBQUUsQ0FETztBQUVYa0IscUJBQUssRUFBRSxTQUZJO0FBR1hqRSx1QkFBTyxFQUFFLGdCQUhFO0FBSVgrRCxzQkFBTSxFQUFFO0FBSkcsZUFBRCxDQU5oQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF0QkYsZUFzQ0U7QUFDRSxtQkFBSyxFQUFFO0FBQ0xnQywrQkFBZSxFQUFFO0FBRFosZUFEVDtBQUlFLHVCQUFTLEVBQUVYLHFFQUFNLENBQUNlLFdBSnBCO0FBS0UscUJBQU8sRUFBRSxNQUNQekMsWUFBWSxDQUFDO0FBQ1hYLGtCQUFFLEVBQUUsQ0FETztBQUVYa0IscUJBQUssRUFBRSxTQUZJO0FBR1hqRSx1QkFBTyxFQUFFLGFBSEU7QUFJWCtELHNCQUFNLEVBQUU7QUFKRyxlQUFELENBTmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdkdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTFKRixlQTBVRTtBQUNFLGFBQUssRUFBRTtBQUNMaUIsbUJBQVMsRUFBRTtBQUROLFNBRFQ7QUFBQSwrQkFLRTtBQUFBLGtDQUNFO0FBQUEsb0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUhGLGVBSUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLEVBUUdwRyxTQUFTLENBQUN1RSxHQUFWLENBQWMsQ0FBQ0wsSUFBRCxFQUFPeEQsS0FBUCxrQkFDYjtBQUFBLG9DQUNFO0FBQUEsd0JBQUtBLEtBQUssR0FBRztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFFRTtBQUFBLHdCQUFLcUIsYUFBYSxDQUFDbUMsSUFBSSxDQUFDN0UsYUFBTjtBQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZGLEVBRStDLEdBRi9DLGVBR0U7QUFBQSx3QkFBSzBDLGFBQWEsQ0FBQ21DLElBQUksQ0FBQzVFLFdBQU47QUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFIRixlQUlFO0FBQ0UsbUJBQUssRUFBRTtBQUNMNkgsK0JBQWUsRUFBRWpELElBQUksQ0FBQ1U7QUFEakIsZUFEVDtBQUlFLHFCQUFPLEVBQUUsTUFBTTtBQUNiaEMsdUJBQU8sQ0FBQ0MsR0FBUixDQUFZcUIsSUFBWjtBQUNELGVBTkg7QUFBQSx3QkFRR0EsSUFBSSxDQUFDaUI7QUFSUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUpGO0FBQUEsYUFBU3pFLEtBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERCxDQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMVVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFsQ0o7QUFBQSxrQkFERjtBQWlaRCxDQWh1QkQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNkQTtBQUNBO0FBQ0E7QUFFZSxTQUFTc0gsSUFBVCxHQUFnQjtBQUM3QixzQkFDRTtBQUFLLGFBQVMsRUFBRXhCLDhEQUFNLENBQUN5QixTQUF2QjtBQUFBLDRCQUNFLHFFQUFDLGdEQUFEO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUVFO0FBQU0sV0FBRyxFQUFDLE1BQVY7QUFBaUIsWUFBSSxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQU1FO0FBQU0sZUFBUyxFQUFFekIsOERBQU0sQ0FBQzBCLElBQXhCO0FBQUEsNkJBQ0UscUVBQUMsbUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQVlELEM7Ozs7Ozs7Ozs7O0FDakJEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ2hCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNKQSxzQzs7Ozs7Ozs7Ozs7QUNBQSxrQzs7Ozs7Ozs7Ozs7QUNBQSwyQzs7Ozs7Ozs7Ozs7QUNBQSwyQzs7Ozs7Ozs7Ozs7QUNBQSwyQzs7Ozs7Ozs7Ozs7QUNBQSxrRCIsImZpbGUiOiJwYWdlcy9pbmRleC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0gcmVxdWlyZSgnLi4vc3NyLW1vZHVsZS1jYWNoZS5qcycpO1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHR2YXIgdGhyZXcgPSB0cnVlO1xuIFx0XHR0cnkge1xuIFx0XHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuIFx0XHRcdHRocmV3ID0gZmFsc2U7XG4gXHRcdH0gZmluYWxseSB7XG4gXHRcdFx0aWYodGhyZXcpIGRlbGV0ZSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXTtcbiBcdFx0fVxuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBcIi4vcGFnZXMvaW5kZXguanNcIik7XG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZVJlZiwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBzdHlsZXMgZnJvbSBcIi4uL3N0eWxlcy9BdWRpb1BsYXllci5tb2R1bGUuY3NzXCI7XHJcbmltcG9ydCB7IEJzQXJyb3dMZWZ0U2hvcnQgfSBmcm9tIFwicmVhY3QtaWNvbnMvYnNcIjtcclxuaW1wb3J0IHsgQnNBcnJvd1JpZ2h0U2hvcnQgfSBmcm9tIFwicmVhY3QtaWNvbnMvYnNcIjtcclxuaW1wb3J0IHsgRmFQbGF5IH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IEZhUGF1c2UgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgTWRPdXRsaW5lUmVwbGF5Q2lyY2xlRmlsbGVkIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcblxyXG5jb25zdCBoaWdoTGlnaHRzID0gW1xyXG4gIHsgc3RhcnRQb3NpdGlvbjogMzAsIGVuZFBvc2l0aW9uOiA0NSB9LFxyXG4gIHsgc3RhcnRQb3NpdGlvbjogNDAsIGVuZFBvc2l0aW9uOiA3MCB9LFxyXG4gIHsgc3RhcnRQb3NpdGlvbjogMjAsIGVuZFBvc2l0aW9uOiA0MCB9LFxyXG5dO1xyXG5cclxuY29uc3QgQXVkaW9QbGF5ZXIgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3N0YXJ0VGltZSwgc2V0U3RhcnRUaW1lXSA9IHVzZVN0YXRlKHtcclxuICAgIGhvdXI6IG51bGwsXHJcbiAgICBtaW46IG51bGwsXHJcbiAgICBzZWM6IG51bGwsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2VuZFRpbWUsIHNldEVuZFRpbWVdID0gdXNlU3RhdGUoe1xyXG4gICAgaG91cjogbnVsbCxcclxuICAgIG1pbjogbnVsbCxcclxuICAgIHNlYzogbnVsbCxcclxuICB9KTtcclxuICBjb25zdCBbYmxvY2tMaXN0LCBzZXRCbG9jYWtMaXN0XSA9IHVzZVN0YXRlKFtcclxuICAgIC8vIHtcclxuICAgIC8vICAgYWN0aW9uOiBcIkV4ZXJjaXNlcyBcIixcclxuICAgIC8vICAgZW5kUG9zaXRpb246IDEzLFxyXG4gICAgLy8gICBpZDogMSxcclxuICAgIC8vICAgc3RhcnRQb3NpdGlvbjogOSxcclxuICAgIC8vICAgdGltZVN0YW1wQ29sb3I6IFwiI0ZGMDAwMFwiLFxyXG4gICAgLy8gfSxcclxuICAgIC8vIHtcclxuICAgIC8vICAgYWN0aW9uOiBcIlF1ZXN0aW9ucyBcIixcclxuICAgIC8vICAgZW5kUG9zaXRpb246IDM2LFxyXG4gICAgLy8gICBpZDogMixcclxuICAgIC8vICAgc3RhcnRQb3NpdGlvbjogMTksXHJcbiAgICAvLyAgIHRpbWVTdGFtcENvbG9yOiBcIiMzMDljMDBcIixcclxuICAgIC8vIH0sXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIFwic3RhcnRQb3NpdGlvblwiOiA0MyxcclxuICAgIC8vICAgXCJlbmRQb3NpdGlvblwiOiA1OSxcclxuICAgIC8vICAgXCJ0aW1lU3RhbXBDb2xvclwiOiBcIiNmZmY0MGZcIixcclxuICAgIC8vICAgXCJpZFwiOiAzLFxyXG4gICAgLy8gICBcImFjdGlvblwiOiBcIk5lZWQgUmV2aWV3IFwiLFxyXG4gICAgLy8gfSxcclxuICAgIC8vIHtcclxuICAgIC8vICAgXCJzdGFydFBvc2l0aW9uXCI6IDQ0LFxyXG4gICAgLy8gICBcImVuZFBvc2l0aW9uXCI6IDUwLFxyXG4gICAgLy8gICBcInRpbWVTdGFtcENvbG9yXCI6IFwiI0ZGMDAwMFwiLFxyXG4gICAgLy8gICBcImlkXCI6IDEsXHJcbiAgICAvLyAgIFwiYWN0aW9uXCI6IFwiRXhlcmNpc2VzIFwiLFxyXG4gICAgLy8gfSxcclxuICBdKTtcclxuICBjb25zdCBbaXNQbGF5aW5nLCBzZXRJc1BsYXlpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtkdXJhdGlvbiwgc2V0RHVyYXRpb25dID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2N1cnJlbnRUaW1lLCBzZXRDdXJyZW50VGltZV0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbaGlnaExpZ2h0QmxvY2tzLCBzZXRIaWdoTGlnaHRCbG9ja3NdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpbmRleCwgc2V0aW5kZXhdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gIGNvbnN0IFtpc1JlcGxheSwgc2V0SXNSZXBsYXldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyByZWZlcmVuY2VzXHJcblxyXG4gIGNvbnN0IFthdWRpbywgc2V0QXVkaW9dID0gdXNlU3RhdGUoKTtcclxuICBjb25zdCBhdWRpb1BsYXllciA9IHVzZVJlZigpOyAvLyByZWZlcmVuY2Ugb3VyIGF1ZGlvIGNvbXBvbmVudFxyXG4gIGNvbnN0IHByb2dyZXNzQmFyID0gdXNlUmVmKCk7IC8vIHJlZmVyZW5jZSBvdXIgcHJvZ3Jlc3MgYmFyXHJcbiAgY29uc3QgYW5pbWF0aW9uUmVmID0gdXNlUmVmKCk7IC8vIHJlZmVyZW5jZSB0aGUgYW5pbWF0aW9uXHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW21heFZhbHVlLCBzZXRNYXhWYWx1ZV0gPSB1c2VTdGF0ZSgpO1xyXG5cclxuICBjb25zdCB1cGxvYWRBdWRpbyA9IChlKSA9PiB7XHJcbiAgICBpZiAoXHJcbiAgICAgIGUudGFyZ2V0LmZpbGVzWzBdPy50eXBlID09PSBcInZpZGVvL21wNFwiIHx8XHJcbiAgICAgIGUudGFyZ2V0LmZpbGVzWzBdPy50eXBlID09PSBcImF1ZGlvL21wZWdcIlxyXG4gICAgKSB7XHJcbiAgICAgIC8vIGNvbnNvbGUubG9nKFwiOmtuXCIpO1xyXG4gICAgICBzZXRBdWRpbyhVUkw/LmNyZWF0ZU9iamVjdFVSTChlLnRhcmdldC5maWxlc1swXSkpO1xyXG4gICAgICBzZXRNZXNzYWdlKFwiXCIpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0TWVzc2FnZShcIlBsZWFzZSBVcGxvYWQgQXVkaW8vVmlkZW8gZmlsZSBcIik7XHJcbiAgICAgIHNldEF1ZGlvKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gY29uc3Qgc2Vjb25kcyA9IE1hdGguZmxvb3IoYXVkaW9QbGF5ZXIuY3VycmVudC5kdXJhdGlvbik7XHJcbiAgICAvLyBjb25zb2xlLmxvZyhcInNlY1wiLCBzZWNvbmRzKTtcclxuICAgIC8vIHNldER1cmF0aW9uKHNlY29uZHMpO1xyXG4gICAgLy8gcHJvZ3Jlc3NCYXIuY3VycmVudC5tYXggPSBzZWNvbmRzO1xyXG4gIH07XHJcbiAgLy8gY29uc3QgY2hlY2tWaWRlb092ZXIgPSAoc2VjKSA9PiB7XHJcbiAgLy8gICBjb25zb2xlLmxvZyhcInNlY1wiLCBzZWMsIFwiZHVyYXRpb25cIiwgZHVyYXRpb24pO1xyXG4gIC8vICAgLy8gaWYgKE51bWJlcihzZWMpID09PSBkdXJhdGlvbikge1xyXG4gIC8vICAgLy8gICBzZXRJc1BsYXlpbmcoZmFsc2UpO1xyXG5cclxuICAvLyAgIC8vIH1cclxuICAvLyB9O1xyXG5cclxuICBjb25zdCBjYWxjdWxhdGVUaW1lID0gKHNlY3MpID0+IHtcclxuICAgIC8vIGNoZWNrVmlkZW9PdmVyKGN1cnJlbnRUaW1lKTtcclxuICAgIC8vIGlmKHNlYylcclxuICAgIGNvbnN0IG1pbnV0ZXMgPSBNYXRoLmZsb29yKHNlY3MgLyA2MCk7XHJcbiAgICBjb25zdCByZXR1cm5lZE1pbnV0ZXMgPSBtaW51dGVzIDwgMTAgPyBgMCR7bWludXRlc31gIDogYCR7bWludXRlc31gO1xyXG4gICAgY29uc3Qgc2Vjb25kcyA9IE1hdGguZmxvb3Ioc2VjcyAlIDYwKTtcclxuICAgIGNvbnN0IHJldHVybmVkU2Vjb25kcyA9IHNlY29uZHMgPCAxMCA/IGAwJHtzZWNvbmRzfWAgOiBgJHtzZWNvbmRzfWA7XHJcbiAgICByZXR1cm4gYCR7cmV0dXJuZWRNaW51dGVzfToke3JldHVybmVkU2Vjb25kc31gO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNhbGN1bGF0ZVRpbWVFbmQgPSAoKSA9PiB7XHJcbiAgICAvLyBjb25zdCBzZWNzID0gTWF0aC5mbG9vcihhdWRpb1BsYXllci5jdXJyZW50LmR1cmF0aW9uKTtcclxuXHJcbiAgICAvLyBjb25zb2xlLmxvZyhcImdldCBhbGwgc2VjXCIsIGF1ZGlvUGxheWVyKTtcclxuICAgIGNvbnN0IG1pbnV0ZXMgPSBNYXRoLmZsb29yKHNlY3MgLyA2MCk7XHJcbiAgICBjb25zdCByZXR1cm5lZE1pbnV0ZXMgPSBtaW51dGVzIDwgMTAgPyBgMCR7bWludXRlc31gIDogYCR7bWludXRlc31gO1xyXG4gICAgY29uc3Qgc2Vjb25kcyA9IE1hdGguZmxvb3Ioc2VjcyAlIDYwKTtcclxuICAgIGNvbnN0IHJldHVybmVkU2Vjb25kcyA9IHNlY29uZHMgPCAxMCA/IGAwJHtzZWNvbmRzfWAgOiBgJHtzZWNvbmRzfWA7XHJcbiAgICByZXR1cm4gYCR7cmV0dXJuZWRNaW51dGVzfToke3JldHVybmVkU2Vjb25kc31gO1xyXG4gIH07XHJcbiAgY29uc3QgW3Nob3csIHNldFNob3ddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IHRvZ2dsZVBsYXlQYXVzZSA9ICgpID0+IHtcclxuICAgIGlmIChOdW1iZXIoY3VycmVudFRpbWUpID09IGR1cmF0aW9uKSB7XHJcbiAgICAgIC8vIGlmICghcHJldlZhbHVlKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiYWR1aWRvIHBsYXllclwiLCBhdWRpb1BsYXllcik7XHJcblxyXG4gICAgICBhdWRpb1BsYXllci5jdXJyZW50LmN1cnJlbnRUaW1lID0gMDtcclxuICAgICAgYXVkaW9QbGF5ZXIuY3VycmVudC5wbGF5KCk7XHJcbiAgICAgIC8vIGF1ZGlvUGxheWVyLmN1cnJlbnQucGxheSgpO1xyXG4gICAgICAvLyBhbmltYXRpb25SZWYuY3VycmVudCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSh3aGlsZVBsYXlpbmcpO1xyXG4gICAgICAvLyB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBwcmV2VmFsdWUgPSBpc1BsYXlpbmc7XHJcbiAgICAgIHNldElzUGxheWluZyghcHJldlZhbHVlKTtcclxuICAgICAgaWYgKCFwcmV2VmFsdWUpIHtcclxuICAgICAgICBhdWRpb1BsYXllci5jdXJyZW50LnBsYXkoKTtcclxuICAgICAgICBhbmltYXRpb25SZWYuY3VycmVudCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSh3aGlsZVBsYXlpbmcpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGF1ZGlvUGxheWVyLmN1cnJlbnQucGF1c2UoKTtcclxuICAgICAgICBjYW5jZWxBbmltYXRpb25GcmFtZShhbmltYXRpb25SZWYuY3VycmVudCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCB3aGlsZVBsYXlpbmcgPSAoKSA9PiB7XHJcbiAgICBwcm9ncmVzc0Jhci5jdXJyZW50LnZhbHVlID0gYXVkaW9QbGF5ZXIuY3VycmVudC5jdXJyZW50VGltZTtcclxuICAgIGNoYW5nZVBsYXllckN1cnJlbnRUaW1lKCk7XHJcbiAgICBhbmltYXRpb25SZWYuY3VycmVudCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSh3aGlsZVBsYXlpbmcpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGJhY2tUaGlydHkgPSAoKSA9PiB7XHJcbiAgICBwcm9ncmVzc0Jhci5jdXJyZW50LnZhbHVlID0gTnVtYmVyKHByb2dyZXNzQmFyLmN1cnJlbnQudmFsdWUgLSAzMCk7XHJcbiAgICBjaGFuZ2VSYW5nZSgpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNoYW5nZVN0YXJ0ZGF0ZSA9IChlKSA9PiB7XHJcbiAgICBzZXRTdGFydFRpbWUoeyAuLi5zdGFydFRpbWUsIFtlLnRhcmdldC5uYW1lXTogZS50YXJnZXQudmFsdWUgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2hhbmdlRW5kVGltZSA9IChlKSA9PiB7XHJcbiAgICBzZXRFbmRUaW1lKHsgLi4uZW5kVGltZSwgW2UudGFyZ2V0Lm5hbWVdOiBlLnRhcmdldC52YWx1ZSB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjb3VudE51bWJlciA9IChudW1iZXIpID0+IHtcclxuICAgIGxldCBob3VyID0gbnVtYmVyPy5ob3VyICogMzYwMCB8fCAwO1xyXG4gICAgbGV0IG1pbiA9IG51bWJlcj8ubWluICogNjAgfHwgMDtcclxuICAgIGxldCBzZWMgPSBOdW1iZXIobnVtYmVyPy5zZWMpICsgTnVtYmVyKG1pbikgKyBOdW1iZXIoaG91cik7XHJcbiAgICByZXR1cm4gc2VjO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldEJsb2NrUG9zaXRpb25zID0gKGhpZ2hMaWdodEl0ZW1EYXRhKSA9PiB7XHJcbiAgICBjb25zdCBmaW5kID0gaGlnaExpZ2h0QmxvY2tzLmZpbHRlcigoZGF0YSkgPT4ge1xyXG4gICAgICBpZiAoZGF0YS5pZCAhPT0gaGlnaExpZ2h0SXRlbURhdGEuaWQpIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgLi4uZGF0YSxcclxuICAgICAgICB9O1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIGlmIChmaW5kLmxlbmd0aCA9PT0gaGlnaExpZ2h0QmxvY2tzLmxlbmd0aCkge1xyXG4gICAgICBjb25zb2xlLmxvZyhcImZpbmQgXCIpO1xyXG5cclxuICAgICAgY29uc3QgZ2V0U2VsZWN0ZERhdGEgPSBibG9ja0xpc3QuZmlsdGVyKChkYXRhKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGRhdGEuaWQgPT09IGhpZ2hMaWdodEl0ZW1EYXRhLmlkO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGFsbCBkYXRhXCIsIGdldFNlbGVjdGREYXRhKTtcclxuXHJcbiAgICAgIGxldCBsaXN0ZGF0YSA9IGdldFNlbGVjdGREYXRhPy5tYXAoKGhpZ2hMaWdodEl0ZW0pID0+IHtcclxuICAgICAgICBsZXQgbGVmdFNwYWNlID0gTWF0aC50cnVuYyhcclxuICAgICAgICAgIChoaWdoTGlnaHRJdGVtPy5zdGFydFBvc2l0aW9uICogNTcwKSAvIGR1cmF0aW9uXHJcbiAgICAgICAgKTtcclxuICAgICAgICBsZXQgZW5kUG9zaXRpb24gPSBNYXRoLnRydW5jKFxyXG4gICAgICAgICAgKGhpZ2hMaWdodEl0ZW0/LmVuZFBvc2l0aW9uICogNTcwKSAvIGR1cmF0aW9uXHJcbiAgICAgICAgKTtcclxuICAgICAgICBsZXQgYmxvY2tXaWR0aCA9IGVuZFBvc2l0aW9uIC0gbGVmdFNwYWNlO1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBsZWZ0U3BhY2U6IGxlZnRTcGFjZSxcclxuICAgICAgICAgIGJsb2NrV2lkdGg6IGJsb2NrV2lkdGgsXHJcbiAgICAgICAgICB0aW1lU3RhbXBDb2xvcjogaGlnaExpZ2h0SXRlbS50aW1lU3RhbXBDb2xvcixcclxuICAgICAgICAgIGlkOiBoaWdoTGlnaHRJdGVtLmlkLFxyXG4gICAgICAgICAgaW5kZXg6IGhpZ2hMaWdodEl0ZW0uaW5kZXggKyAxIHx8IGluZGV4ICsgMSxcclxuICAgICAgICB9O1xyXG4gICAgICB9KTtcclxuICAgICAgc2V0SGlnaExpZ2h0QmxvY2tzKFsuLi5saXN0ZGF0YSwgLi4uaGlnaExpZ2h0QmxvY2tzXSk7XHJcbiAgICAgIHNldGluZGV4KGluZGV4ICsgMSk7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwibGlzdGRhdGFcIiwgbGlzdGRhdGEpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgbGV0IGNoYW5nZUluZGV4ID0gZmluZC5tYXAoKGRhdGEpID0+IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgLi4uZGF0YSxcclxuICAgICAgICAgIGluZGV4OiBkYXRhLmluZGV4ICE9PSAxID8gZGF0YS5pbmRleCAtIDEgOiBkYXRhLmluZGV4LFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgaWYgKGluZGV4ID4gMSkge1xyXG4gICAgICAgIHNldGluZGV4KGluZGV4IC0gMSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0aW5kZXgoMCk7XHJcbiAgICAgIH1cclxuICAgICAgc2V0SGlnaExpZ2h0QmxvY2tzKGNoYW5nZUluZGV4KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBhZGRFeGVyY2lzZXMgPSAoZGV0YWlscykgPT4ge1xyXG4gICAgbGV0IHN0YXJ0aW1lID0gY291bnROdW1iZXIoc3RhcnRUaW1lKTtcclxuICAgIGxldCBlbmR0aW1lID0gY291bnROdW1iZXIoZW5kVGltZSk7XHJcblxyXG4gICAgaWYgKHN0YXJ0aW1lIDwgZW5kdGltZSAmJiBkdXJhdGlvbiA+IHN0YXJ0aW1lICYmIGR1cmF0aW9uID49IGVuZHRpbWUpIHtcclxuICAgICAgY29uc3QgZXhpc3QgPSBibG9ja0xpc3QuZmlsdGVyKChkYXRhKSA9PiB7XHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgKHN0YXJ0aW1lID49IGRhdGE/LnN0YXJ0UG9zaXRpb24gJiZcclxuICAgICAgICAgICAgc3RhcnRpbWUgPD0gZGF0YT8uZW5kUG9zaXRpb24gJiZcclxuICAgICAgICAgICAgZGF0YT8uYWN0aW9uID09PSBkZXRhaWxzPy5hY3Rpb24pIHx8XHJcbiAgICAgICAgICAoZW5kdGltZSA+PSBkYXRhPy5zdGFydFBvc2l0aW9uICYmXHJcbiAgICAgICAgICAgIGVuZHRpbWUgPD0gZGF0YT8uZW5kUG9zaXRpb24gJiZcclxuICAgICAgICAgICAgZGF0YT8uYWN0aW9uID09PSBkZXRhaWxzPy5hY3Rpb24pIHx8XHJcbiAgICAgICAgICAoc3RhcnRpbWUgPD0gZGF0YT8uc3RhcnRQb3NpdGlvbiAmJlxyXG4gICAgICAgICAgICBlbmR0aW1lID49IGRhdGE/LmVuZFBvc2l0aW9uICYmXHJcbiAgICAgICAgICAgIGRhdGE/LmFjdGlvbiA9PT0gZGV0YWlscz8uYWN0aW9uKVxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgcmV0dXJuIGRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGlmIChleGlzdD8ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHNldE1lc3NhZ2UoZGV0YWlscz8uYWN0aW9uLnJlcGxhY2UoXCJzXCIsIFwiXCIpICsgXCJUaW1lIGlzIEV4c2l0c1wiKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRCbG9jYWtMaXN0KFtcclxuICAgICAgICAgIC4uLmJsb2NrTGlzdCxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgc3RhcnRQb3NpdGlvbjogc3RhcnRpbWUsXHJcbiAgICAgICAgICAgIGVuZFBvc2l0aW9uOiBlbmR0aW1lLFxyXG4gICAgICAgICAgICB0aW1lU3RhbXBDb2xvcjogZGV0YWlscy5jb2xvcixcclxuICAgICAgICAgICAgaWQ6IGRldGFpbHMuaWQsXHJcbiAgICAgICAgICAgIGFjdGlvbjogZGV0YWlscy5hY3Rpb24sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF0pO1xyXG5cclxuICAgICAgICBzZXRTdGFydFRpbWUoe1xyXG4gICAgICAgICAgaG91cjogMCxcclxuICAgICAgICAgIG1pbjogMCxcclxuICAgICAgICAgIHNlYzogMCxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0RW5kVGltZSh7XHJcbiAgICAgICAgICBob3VyOiAwLFxyXG4gICAgICAgICAgbWluOiAwLFxyXG4gICAgICAgICAgc2VjOiAwLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldE1lc3NhZ2UoXCJcIik7XHJcbiAgICAgICAgYWxlcnQoZGV0YWlscy5tZXNzYWdlICsgXCJUaW1lIGlzIGFkZGVkXCIpO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRNZXNzYWdlKFwiUGxlYXNlIEVudGVyIFZhbGlkIFRpbWVcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2FsY3VsYXRlRW5kVGltZSA9ICgpID0+IHt9O1xyXG4gIGNvbnN0IHN1Ym10SW1hZ2UgPSAoKSA9PiB7XHJcbiAgICAvLyBjb25zdCBzZWNvbmRzID0gTWF0aC5mbG9vcihhdWRpb1BsYXllci5jdXJyZW50LmR1cmF0aW9uKTtcclxuICAgIC8vIHNldER1cmF0aW9uKHNlY29uZHMpO1xyXG4gICAgLy8gcHJvZ3Jlc3NCYXIuY3VycmVudC5tYXggPSBzZWNvbmRzO1xyXG5cclxuICAgIHNldFNob3codHJ1ZSk7XHJcblxyXG4gICAgLy8gc2V0QXVkaW8oZSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBjb25zdCBzZWNvbmRzID0gTWF0aC5mbG9vcihhdWRpb1BsYXllcj8uY3VycmVudD8uZHVyYXRpb24pO1xyXG4gICAgICBzZXREdXJhdGlvbihzZWNvbmRzKTtcclxuICAgICAgc2V0TWF4VmFsdWUoc2Vjb25kcyk7XHJcbiAgICB9LCAzMDApO1xyXG4gIH0sIFtoaWdoTGlnaHRCbG9ja3MsIGF1ZGlvLCBkdXJhdGlvbiwgc2hvd10pO1xyXG5cclxuICAvLyB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gIC8vICAgLy8gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgLy8gICAvLyAgIGNvbnN0IHNlY29uZHMgPSBNYXRoLmZsb29yKGF1ZGlvUGxheWVyPy5jdXJyZW50Py5kdXJhdGlvbik7XHJcbiAgLy8gICAvLyAgIHNldER1cmF0aW9uKHNlY29uZHMpO1xyXG4gIC8vICAgLy8gICBzZXRNYXhWYWx1ZShzZWNvbmRzKTtcclxuICAvLyAgIC8vIH0sIDMwMCk7XHJcblxyXG4gIC8vICAgY29uc29sZS5sb2coXCJuYWtzY25rblwiKTtcclxuICAvLyB9LCBbYXVkaW9QbGF5ZXI/LmN1cnJlbnQ/LnZhbHVlXSk7XHJcblxyXG4gIGNvbnN0IGZvcndhcmRUaGlydHkgPSAoKSA9PiB7XHJcbiAgICBwcm9ncmVzc0Jhci5jdXJyZW50LnZhbHVlID0gTnVtYmVyKHByb2dyZXNzQmFyLmN1cnJlbnQudmFsdWUgKyAzMCk7XHJcbiAgICBjaGFuZ2VSYW5nZSgpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNoYW5nZVJhbmdlID0gKCkgPT4ge1xyXG4gICAgYXVkaW9QbGF5ZXIuY3VycmVudC5jdXJyZW50VGltZSA9IHByb2dyZXNzQmFyLmN1cnJlbnQudmFsdWU7XHJcbiAgICBjaGFuZ2VQbGF5ZXJDdXJyZW50VGltZSgpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNoYW5nZVBsYXllckN1cnJlbnRUaW1lID0gKCkgPT4ge1xyXG4gICAgcHJvZ3Jlc3NCYXIuY3VycmVudC5zdHlsZS5zZXRQcm9wZXJ0eShcclxuICAgICAgXCItLXNlZWstYmVmb3JlLXdpZHRoXCIsXHJcbiAgICAgIGAkeyhwcm9ncmVzc0Jhci5jdXJyZW50LnZhbHVlIC8gZHVyYXRpb24pICogMTAwfSVgXHJcbiAgICApO1xyXG4gICAgc2V0Q3VycmVudFRpbWUocHJvZ3Jlc3NCYXIuY3VycmVudC52YWx1ZSk7XHJcbiAgfTtcclxuICBjb25zdCBnZXROZXdEYXRhID0gKGUpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKFxyXG4gICAgICBlLnRhcmdldC5wYXJlbnRFbGVtZW50Lm9mZnNldExlZnQgK1xyXG4gICAgICAgIGUudGFyZ2V0LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5vZmZzZXRMZWZ0LFxyXG4gICAgICBcInRvYXRhbFwiLFxyXG4gICAgICBlLnNjcmVlblhcclxuICAgICk7XHJcblxyXG4gICAgY29uc29sZS5sb2coXHJcbiAgICAgIFwiZmluYWwgXCIsXHJcbiAgICAgIGUudGFyZ2V0LnBhcmVudEVsZW1lbnQub2Zmc2V0TGVmdCArXHJcbiAgICAgICAgZS50YXJnZXQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50Lm9mZnNldExlZnQgLVxyXG4gICAgICAgIGUuc2NyZWVuWFxyXG4gICAgKTtcclxuICAgIGxldCB0aW1lO1xyXG4gICAgdGltZSA9XHJcbiAgICAgIChlLnRhcmdldC5wYXJlbnRFbGVtZW50Lm9mZnNldExlZnQgK1xyXG4gICAgICAgIGUudGFyZ2V0LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5vZmZzZXRMZWZ0IC1cclxuICAgICAgICBlLnNjcmVlblgpIC9cclxuICAgICAgKDU3MCAvIGR1cmF0aW9uKTtcclxuICAgIGNvbnNvbGUubG9nKFwidGltZSBcIiwgdGltZSk7XHJcbiAgICBwcm9ncmVzc0Jhci5jdXJyZW50LnZhbHVlID0gTWF0aC5hYnMoTWF0aC5mbG9vcih0aW1lKSk7XHJcblxyXG4gICAgY2hhbmdlUmFuZ2UoKTtcclxuICB9O1xyXG5cclxuICAvLyBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHshc2hvdyAmJiAoXHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxkaXY+VXBsb2FkIEF1ZGlvL1ZpZGVvPC9kaXY+XHJcbiAgICAgICAgICB7bWVzc2FnZSAmJiAoXHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgLy8gcG9zaXRpb246IFwiYWJzb2x1dGVcIixcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBcInJlZFwiLFxyXG4gICAgICAgICAgICAgICAgLy8gdG9wOiBcIjUwcHhcIixcclxuICAgICAgICAgICAgICAgIC8vIGxlZnQ6IDUwLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luVG9wOiAxMCxcclxuICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogNSxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge21lc3NhZ2V9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIG9uQ2hhbmdlPXt1cGxvYWRBdWRpb30gLz5cclxuXHJcbiAgICAgICAgICB7YXVkaW8gJiYgKFxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17c3VibXRJbWFnZX1cclxuICAgICAgICAgICAgICAvLyBzdHlsZT17e1xyXG4gICAgICAgICAgICAgIC8vICAgb3BhY2l0eTogc2hvdyA/IDEwMCA6IDI0LFxyXG4gICAgICAgICAgICAgIC8vIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBVcGxvYWQgQXVkaW8vVmlkZW9cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAge3Nob3cgJiYgKFxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMuYXVkaW9QbGF5ZXJ9XHJcbiAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIsXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDx2aWRlb1xyXG4gICAgICAgICAgICAgICAgcmVmPXthdWRpb1BsYXllcn1cclxuICAgICAgICAgICAgICAgIHNyYz17YXVkaW99XHJcbiAgICAgICAgICAgICAgICBwcmVsb2FkPVwibWV0YWRhdGFcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAzMjYsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgID48L3ZpZGVvPlxyXG4gICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLm1haW5SYW5nZX1cclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBcImFic29sdXRlXCIsXHJcbiAgICAgICAgICAgICAgICAgIHRvcDogMzAwLFxyXG4gICAgICAgICAgICAgICAgICB3aWR0aDogNTcwLFxyXG4gICAgICAgICAgICAgICAgICAvLyB6SW5kZXg6IDEwLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBnZXROZXdEYXRhKGUpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5wcm9ncmVzc0Jhcn1cclxuICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXswfVxyXG4gICAgICAgICAgICAgICAgICByZWY9e3Byb2dyZXNzQmFyfVxyXG4gICAgICAgICAgICAgICAgICBtYXg9e21heFZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBwb2ludGVyRXZlbnRzOiBcIm5vbmVcIiB9fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuc2Vla0Jhcn0+XHJcbiAgICAgICAgICAgICAgICAgIHtoaWdoTGlnaHRCbG9ja3M/Lm1hcCgoZGF0YSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMuc2Vla0JhcjF9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogYCR7ZGF0YS5ibG9ja1dpZHRofXB4YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBcIjYwJVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiBgJHtkYXRhLmxlZnRTcGFjZX1weGAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogYCR7ZGF0YS50aW1lU3RhbXBDb2xvcn1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLjcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHpJbmRleDogZGF0YS5pbmRleCxcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuYnV0dG9ubGlzdH0+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBcIiNGRjAwMDBcIixcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5idXR0b25TdHlsZX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZ2V0QmxvY2tQb3NpdGlvbnMoeyBpZDogMSB9KTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgRXhlcmNpc2VzXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBcIiMzMDljMDBcIixcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5idXR0b25TdHlsZX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGdldEJsb2NrUG9zaXRpb25zKHsgaWQ6IDIgfSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgUXVlc3Rpb25zXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMuYnV0dG9uU3R5bGV9XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI2ZmZjQwZlwiLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGdldEJsb2NrUG9zaXRpb25zKHsgaWQ6IDMgfSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgTmVlZCBSZXZpZXdcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgICAganVzdGlmeUl0ZW1zOiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICAgIG1hcmdpbkxlZnQ6IDYyLFxyXG4gICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgYmxhY2tcIixcclxuICAgICAgICAgICAgICBtYXhXaWR0aDogMTU3LFxyXG4gICAgICAgICAgICAgIG1hcmdpblRvcDogMTAsXHJcbiAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICAgICAgICAgICAgICBnYXA6IDEwLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7LyogPGJ1dHRvbiBjbGFzc05hbWU9e3N0eWxlcy5mb3J3YXJkQmFja3dhcmR9IG9uQ2xpY2s9e2JhY2tUaGlydHl9PlxyXG4gICAgICAgICAgICAgIDxCc0Fycm93TGVmdFNob3J0IC8+IDMwXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPiAqL31cclxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVQbGF5UGF1c2V9IGNsYXNzTmFtZT17c3R5bGVzLnBsYXlQYXVzZX0+XHJcbiAgICAgICAgICAgICAge051bWJlcihjdXJyZW50VGltZSkgIT09IGR1cmF0aW9uID8gKFxyXG4gICAgICAgICAgICAgICAgaXNQbGF5aW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICA8RmFQYXVzZSAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPEZhUGxheSAvPlxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8TWRPdXRsaW5lUmVwbGF5Q2lyY2xlRmlsbGVkIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7LyogcGxheSBub3cgKi99XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jdXJyZW50VGltZX0+ICovfVxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIHtjYWxjdWxhdGVUaW1lKGN1cnJlbnRUaW1lKX0vey8qIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5kdXJhdGlvbn0+ICovfVxyXG4gICAgICAgICAgICAgIHsvKiB7Y2FsY3VsYXRlRW5kVGltZShkdXJhdGlvbil9ICovfVxyXG4gICAgICAgICAgICAgIHsvKiB7Y2FsY3VsYXRlVGltZUVuZCgpfSAqL31cclxuICAgICAgICAgICAgICB7ZHVyYXRpb24gJiYgIWlzTmFOKGR1cmF0aW9uKSAmJiBjYWxjdWxhdGVUaW1lKGR1cmF0aW9uKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHsvKiA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgIHsvKiA8YnV0dG9uIGNsYXNzTmFtZT17c3R5bGVzLmZvcndhcmRCYWNrd2FyZH0gb25DbGljaz17Zm9yd2FyZFRoaXJ0eX0+XHJcbiAgICAgICAgICAgICAgMzAgPEJzQXJyb3dSaWdodFNob3J0IC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPiAqL31cclxuICAgICAgICAgICAgey8qIGN1cnJlbnQgdGltZSAqL31cclxuICAgICAgICAgICAgey8qIHByb2dyZXNzIGJhciAqL31cclxuICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwicHJvZ3Jlc3MtNCByZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgIHtoaWdoTGlnaHRCbG9ja3MubGVuZ3RoID4gMCAmJlxyXG4gICAgICAgICAgICAgICAgaGlnaExpZ2h0QmxvY2tzLm1hcCgoaGlnaExpZ2h0QmxvY2spID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKGhpZ2hMaWdodEJsb2NrLmxlZnRTcGFjZSB8fCBoaWdoTGlnaHRCbG9jay5ibG9ja1dpZHRoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGJsb2NrU3R5bGUgPSBgdy1bJHtoaWdoTGlnaHRCbG9jay5ibG9ja1dpZHRofXB4XSBsZWZ0LVske2hpZ2hMaWdodEJsb2NrLmxlZnRTcGFjZX1weF0gYDtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB3aWR0aD17aGlnaExpZ2h0QmxvY2suYmxvY2tXaWR0aCArIFwicHhcIn1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHByb2dyZXNzICR7YmxvY2tTdHlsZX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICB7LyogZHVyYXRpb24gKi99XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImN1c3RvbVwiXHJcbiAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgcG9zaXRpb246IFwicmVsYXRpdmVcIixcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxyXG4gICAgICAgICAgICAgICAgY29sb3I6IFwicmVkXCIsXHJcbiAgICAgICAgICAgICAgICB0b3A6IFwiNTBweFwiLFxyXG4gICAgICAgICAgICAgICAgbGVmdDogNTAsXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHttZXNzYWdlfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIlwiXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcclxuICAgICAgICAgICAgICAgIGdhcDogNDAsXHJcbiAgICAgICAgICAgICAgICBtYXJnaW5MZWZ0OiA1MCxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgICAgICAgIGdhcDogMTAsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhcnRwb3NpdG9uXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+IFN0YXJ0IFRpbWU8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbGxsYWJlbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtkdXJhdGlvbiA+IDM2MDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImhvdXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtYXg9ezIzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSEhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdGFydFRpbWUuaG91cn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17Y2hhbmdlU3RhcnRkYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICB7ZHVyYXRpb24gPiA2MCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibWluXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4PXs1OX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3RhcnRUaW1lLm1pbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk1NXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17Y2hhbmdlU3RhcnRkYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInNlY1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gbWF4PXs2MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3N0YXJ0VGltZS5zZWN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU1NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXg9ezU5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17Y2hhbmdlU3RhcnRkYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhcnRwb3NpdG9uXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+IEVuZCBUaW1lPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFsbGxhYmVsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2R1cmF0aW9uID4gMzYwMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiaG91clwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1heD17MjR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJISFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VuZFRpbWUuaG91cn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17Y2hhbmdlRW5kVGltZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAge2R1cmF0aW9uID4gNjAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm1pblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1heD17NTl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VuZFRpbWUubWlufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTU1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtjaGFuZ2VFbmRUaW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwic2VjXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXg9ezU5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5kVGltZS5zZWN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU1NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17Y2hhbmdlRW5kVGltZX1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgICAgICAgIGdhcDogMTAsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI0ZGMDAwMFwiLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5idXR0b25TdHlsZX1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICBhZGRFeGVyY2lzZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ6IDEsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjRkYwMDAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIkV4ZXJjaXNlcyBUaW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBhY3Rpb246IFwiRXhlcmNpc2VzIFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQWRkIEV4ZXJjaXNlcyBUaW1lXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiIzMwOWMwMFwiLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5idXR0b25TdHlsZX1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICBhZGRFeGVyY2lzZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjMzA5YzAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlF1ZXN0aW9ucyBUaW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBhY3Rpb246IFwiUXVlc3Rpb25zIFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQWRkIFF1ZXN0aW9ucyBUaW1lXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiI2ZmZjQwZlwiLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5idXR0b25TdHlsZX1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICBhZGRFeGVyY2lzZXMoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ6IDMsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjZmZmNDBmXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlJldmlldyBUaW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBhY3Rpb246IFwiTmVlZCBSZXZpZXcgXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBBZGQgTmVlZCBSZXZpZXcgVGltZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgbWFyZ2luVG9wOiAxMDAsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDx0YWJsZT5cclxuICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICA8dGg+SW5kZXg8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoPlN0YXJ0aW1lPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aD5FbmRUaW1lPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aD5BY3Rpb248L3RoPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcblxyXG4gICAgICAgICAgICAgIHtibG9ja0xpc3QubWFwKChkYXRhLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPHRyIGtleT17aW5kZXh9PlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+e2luZGV4ICsgMX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+e2NhbGN1bGF0ZVRpbWUoZGF0YS5zdGFydFBvc2l0aW9uKX08L3RkPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgPHRkPntjYWxjdWxhdGVUaW1lKGRhdGEuZW5kUG9zaXRpb24pfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZFxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGRhdGEudGltZVN0YW1wQ29sb3IsXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2RhdGEuYWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCB7IEF1ZGlvUGxheWVyIH07XHJcbiIsImltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCdcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzJ1xyXG5pbXBvcnQgeyBBdWRpb1BsYXllciB9IGZyb20gXCIuLi9jb21wb25lbnRzL0F1ZGlvUGxheWVyXCJcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY29udGFpbmVyfT5cclxuICAgICAgPEhlYWQ+XHJcbiAgICAgICAgPHRpdGxlPlJlYWN0IEF1ZGlvIFBsYXllcjwvdGl0bGU+XHJcbiAgICAgICAgPGxpbmsgcmVsPVwiaWNvblwiIGhyZWY9XCIvZmF2aWNvbi5pY29cIiAvPlxyXG4gICAgICA8L0hlYWQ+XHJcblxyXG4gICAgICA8bWFpbiBjbGFzc05hbWU9e3N0eWxlcy5tYWlufT5cclxuICAgICAgICA8QXVkaW9QbGF5ZXIgLz5cclxuICAgICAgPC9tYWluPlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcbiIsIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcImF1ZGlvUGxheWVyXCI6IFwiQXVkaW9QbGF5ZXJfYXVkaW9QbGF5ZXJfX1hDZFZCXCIsXG5cdFwiZm9yd2FyZEJhY2t3YXJkXCI6IFwiQXVkaW9QbGF5ZXJfZm9yd2FyZEJhY2t3YXJkX18xYlFnWFwiLFxuXHRcInBsYXlQYXVzZVwiOiBcIkF1ZGlvUGxheWVyX3BsYXlQYXVzZV9fM2JxRk5cIixcblx0XCJwbGF5XCI6IFwiQXVkaW9QbGF5ZXJfcGxheV9fVjhaNVFcIixcblx0XCJjdXJyZW50VGltZVwiOiBcIkF1ZGlvUGxheWVyX2N1cnJlbnRUaW1lX18yc05jZ1wiLFxuXHRcImR1cmF0aW9uXCI6IFwiQXVkaW9QbGF5ZXJfZHVyYXRpb25fXzFZc1k1XCIsXG5cdFwicHJvZ3Jlc3NCYXJcIjogXCJBdWRpb1BsYXllcl9wcm9ncmVzc0Jhcl9fOVZMbkJcIixcblx0XCJtYWluUmFuZ2VcIjogXCJBdWRpb1BsYXllcl9tYWluUmFuZ2VfXzI1eUlPXCIsXG5cdFwic2Vla0JhclwiOiBcIkF1ZGlvUGxheWVyX3NlZWtCYXJfXzFET2YxXCIsXG5cdFwic2Vla0JhcjFcIjogXCJBdWRpb1BsYXllcl9zZWVrQmFyMV9fMUdXaGhcIixcblx0XCJzZWVrQmFyMlwiOiBcIkF1ZGlvUGxheWVyX3NlZWtCYXIyX18xUDRrVlwiLFxuXHRcInNlZWtCYXIzXCI6IFwiQXVkaW9QbGF5ZXJfc2Vla0JhcjNfXzEtTlV3XCIsXG5cdFwiYnV0dG9ubGlzdFwiOiBcIkF1ZGlvUGxheWVyX2J1dHRvbmxpc3RfXzFnUTU0XCIsXG5cdFwiYnV0dG9uU3R5bGVcIjogXCJBdWRpb1BsYXllcl9idXR0b25TdHlsZV9fWHVxVENcIlxufTtcbiIsIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcImNvbnRhaW5lclwiOiBcIkhvbWVfY29udGFpbmVyX18xRWNzVVwiLFxuXHRcIm1haW5cIjogXCJIb21lX21haW5fXzF4OGdDXCJcbn07XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2hlYWRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtaWNvbnMvYnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtaWNvbnMvZmFcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtaWNvbnMvbWRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOyJdLCJzb3VyY2VSb290IjoiIn0=